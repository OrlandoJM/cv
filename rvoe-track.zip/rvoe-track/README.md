# RVOE·Track — Guía de instalación y despliegue

Sistema de gestión de expedientes RVOE para área jurídica corporativa.

---

## Stack tecnológico

| Capa | Tecnología | Costo estimado |
|---|---|---|
| Frontend + Backend | Next.js 14 (App Router) en Vercel | Gratis (Hobby) |
| Base de datos + Auth | Supabase (PostgreSQL + Auth + RLS) | Gratis hasta 500MB |
| Correo de alertas | Resend | Gratis hasta 3,000/mes |
| Cron de alertas | Vercel Cron (incluido en Hobby) | Gratis |

**Costo mensual estimado: $0 USD** para el volumen esperado.

---

## Paso 1 — Crear proyecto en Supabase

1. Ir a [supabase.com](https://supabase.com) → New Project
2. Elegir región: **us-east-1** o **sa-east-1** (São Paulo, más cercano)
3. Guardar contraseña de la base de datos
4. Ir a **SQL Editor → New Query**
5. Copiar y ejecutar el contenido de `supabase/schema.sql`
6. Verificar que se crearon las tablas en **Table Editor**

### Obtener credenciales de Supabase

En **Project Settings → API**:
- `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
- `anon public` → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `service_role secret` → `SUPABASE_SERVICE_ROLE_KEY`

---

## Paso 2 — Configurar Resend (correo)

1. Crear cuenta en [resend.com](https://resend.com)
2. Agregar y verificar tu dominio de correo
3. Crear API Key → `RESEND_API_KEY`
4. Definir correo remitente → `RESEND_FROM_EMAIL` (ej. `rvoe@tudominio.mx`)

---

## Paso 3 — Crear usuarios iniciales

En Supabase → **Authentication → Users → Invite user**:
1. Invitar a cada abogada por correo
2. Una vez que acepten, ir a **SQL Editor** y ejecutar:

```sql
-- Asignar rol admin_juridica a la administradora
UPDATE usuarios SET rol = 'admin_juridica'
WHERE email = 'mgarcia@tudominio.mx';

-- Asignar rol abogada
UPDATE usuarios SET rol = 'abogada'
WHERE email = 'lherrera@tudominio.mx';
```

---

## Paso 4 — Desplegar en Vercel

1. Hacer push del proyecto a GitHub
2. Ir a [vercel.com](https://vercel.com) → New Project → importar el repo
3. Agregar variables de entorno (copiar de `.env.local.example`):

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
RESEND_API_KEY=
RESEND_FROM_EMAIL=
NEXT_PUBLIC_APP_URL=https://tu-proyecto.vercel.app
CRON_SECRET=genera-un-string-aleatorio-largo
```

4. Click en **Deploy**
5. El cron de alertas se ejecutará automáticamente de lunes a viernes a las 7:00 AM

---

## Paso 5 — Agregar universidades

Una vez desplegado, iniciar sesión con la cuenta `admin_juridica` y navegar a:
- Si no se ven universidades en el dashboard, insertar directamente en Supabase:

```sql
INSERT INTO universidades (nombre, clave_sep) VALUES
  ('Universidad Iberoamericana León', 'DGES-01-234'),
  ('Instituto Superior de Negocios', 'DGES-02-891');
```

---

## Estructura del proyecto

```
rvoe-track/
├── supabase/
│   └── schema.sql          ← Ejecutar primero en Supabase SQL Editor
├── src/
│   ├── app/
│   │   ├── (app)/          ← Rutas protegidas (requieren autenticación)
│   │   │   ├── dashboard/
│   │   │   ├── expedientes/
│   │   │   └── admin/
│   │   ├── api/cron/       ← Cron de alertas diarias
│   │   └── login/
│   ├── components/
│   │   └── ui/             ← Sidebar, SemaforoChip, PageHeader, etc.
│   ├── lib/
│   │   ├── fechas.ts       ← Motor de cálculo de días hábiles
│   │   ├── data.ts         ← Capa de acceso a datos (Supabase)
│   │   ├── alertas.ts      ← Servicio de envío de correos (Resend)
│   │   └── supabase.ts     ← Clientes Supabase (browser + server)
│   ├── types/
│   │   └── index.ts        ← Tipos TypeScript del dominio
│   └── middleware.ts       ← Protección de rutas + control de roles
├── vercel.json             ← Configuración de cron
└── .env.local.example      ← Variables de entorno necesarias
```

---

## Motor de cálculo — cómo funciona

El archivo `src/lib/fechas.ts` contiene la lógica central:

1. **`sumarDiasHabiles(fechaBase, n, inhabiles)`**
   - Suma N días hábiles a una fecha
   - El cómputo empieza el día **siguiente** a la fecha base
   - Soporta N negativo (restar días, para plazos "antes de")
   - Excluye sábados, domingos y los registros de `dias_inhabiles`

2. **`calcularFechaRegla(expediente, regla, inhabiles)`**
   - Evalúa si la regla aplica (tipo_tramite + condición JSONB)
   - Obtiene la fecha base del campo definido en la regla
   - Llama a `sumarDiasHabiles` o `sumarDiasNaturales`

3. **`calcularEtapasExpediente(expediente, reglas, inhabiles)`**
   - Itera todas las reglas activas
   - Para cada una, intenta calcular la fecha
   - Retorna etapas ordenadas por fecha

4. **`calcularSemaforo(fechaCalculada, hoy, umbrales)`**
   - Rojo: fecha vencida O ≤ 3 días hábiles
   - Amarillo: ≤ 15 días hábiles
   - Verde: más de 15 días hábiles

---

## Seguridad — Row Level Security

Cada tabla tiene políticas RLS en Supabase:

- `admin_juridica`: acceso total a todas las tablas
- `abogada`: puede crear/editar expedientes de sus universidades
- `consulta`: solo lectura, sin modificar reglas ni fechas

El middleware de Next.js verifica la sesión en cada request y redirige a `/login` si no hay sesión activa.

---

## Alertas por correo

El cron `/api/cron/alertas` se ejecuta diariamente (lunes-viernes, 7 AM):

1. Obtiene configuración de `alertas_config`
2. Busca etapas no completadas con fecha calculada
3. Compara si hoy es alguna de las fechas de alerta (15, 10, 5, 3, 1 días antes)
4. Verifica si ya se envió esa alerta hoy (evita duplicados)
5. Envía correo vía Resend con plantilla HTML
6. Registra en `alertas_log` (éxito o error)

---

## v2 — Funcionalidades futuras

- [ ] Integración con Microsoft Teams (webhooks)
- [ ] Azure AD / SSO corporativo
- [ ] Almacenamiento de archivos en Supabase Storage
- [ ] Página de edición de expedientes
- [ ] Exportar expediente a PDF
- [ ] Recálculo masivo de etapas desde Admin
- [ ] Notificaciones push en navegador
