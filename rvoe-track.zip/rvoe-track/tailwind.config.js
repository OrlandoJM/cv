/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        bg:      '#0f1117',
        surface: '#161b27',
        card:    '#1c2333',
        border:  '#2a3350',
        muted:   '#7a85a3',
        accent:  '#4f8ef7',
        accent2: '#7c5cfc',
        green:   '#22c98e',
        yellow:  '#f5c842',
        red:     '#f55a5a',
        text:    '#e8eaf0',
      },
      fontFamily: {
        head: ['Fraunces', 'serif'],
        body: ['DM Sans', 'sans-serif'],
        mono: ['DM Mono', 'monospace'],
      },
      borderRadius: { DEFAULT: '8px', lg: '14px', full: '9999px' },
      boxShadow: { card: '0 4px 24px rgba(0,0,0,.4)' },
    },
  },
  plugins: [],
}
