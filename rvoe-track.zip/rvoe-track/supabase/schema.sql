-- ============================================================
-- RVOE·Track — Schema PostgreSQL para Supabase
-- Versión: 1.0.0 (MVP)
-- Ejecutar en: Supabase → SQL Editor → New Query
-- ============================================================

-- Extensiones necesarias
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- ============================================================
-- ENUMERACIONES
-- ============================================================

create type tipo_tramite_enum as enum (
  'nuevo_rvoe',
  'modificacion',
  'cambio_posterior',
  'retiro_rvoe',
  'reglamento_escolar',
  'documentacion_escolar',
  'otro'
);

create type estado_expediente_enum as enum (
  'borrador',
  'en_proceso',
  'en_prevencion',
  'en_revision',
  'resuelto',
  'cerrado',
  'archivado'
);

create type rol_usuario_enum as enum (
  'admin_juridica',
  'abogada',
  'consulta'
);

create type tipo_dias_enum as enum (
  'habiles',
  'naturales'
);

create type semaforo_enum as enum (
  'verde',
  'amarillo',
  'rojo',
  'gris'
);

create type canal_alerta_enum as enum (
  'email',
  'teams',
  'ambos'
);

create type tipo_dia_inhabil_enum as enum (
  'nacional',
  'sep',
  'otro'
);

-- ============================================================
-- TABLA: universidades
-- ============================================================

create table universidades (
  id          uuid primary key default uuid_generate_v4(),
  nombre      text not null,
  clave_sep   text,
  activa      boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

comment on table universidades is 'Instituciones educativas gestionadas en el sistema';

-- ============================================================
-- TABLA: usuarios (extiende auth.users de Supabase)
-- ============================================================

create table usuarios (
  id              uuid primary key references auth.users(id) on delete cascade,
  nombre          text not null,
  email           text not null unique,
  rol             rol_usuario_enum not null default 'consulta',
  universidad_ids uuid[] not null default '{}',
  activo          boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

comment on table usuarios is 'Perfil extendido de usuarios (vinculado a auth.users)';
comment on column usuarios.universidad_ids is 'Array de IDs de universidades a las que tiene acceso. Vacío = acceso a todas (admin)';

-- ============================================================
-- TABLA: expedientes
-- ============================================================

create table expedientes (
  id                      uuid primary key default uuid_generate_v4(),
  folio                   text not null unique,
  universidad_id          uuid not null references universidades(id),
  programa_academico      text not null,
  tipo_tramite            tipo_tramite_enum not null,
  autoridad               text not null,
  estado                  estado_expediente_enum not null default 'borrador',
  responsable_id          uuid references usuarios(id),

  -- Fechas del proceso
  fecha_inicio            date,
  fecha_presentacion      date,
  fecha_notificacion      date,
  fecha_prevencion        date,
  fecha_subsanacion       date,
  fecha_resolucion        date,
  fecha_obtencion_rvoe    date,
  inicio_siguiente_ciclo  date,

  -- Flags para el motor de reglas
  participa_acreditadora  boolean not null default false,
  es_programa_salud       boolean not null default false,

  -- Metadatos
  comentarios             text,
  activo                  boolean not null default true,
  created_by              uuid references usuarios(id),
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now()
);

comment on table expedientes is 'Expedientes de trámites RVOE';
comment on column expedientes.folio is 'Folio interno único, ej. RVOE-2025-001';
comment on column expedientes.participa_acreditadora is 'Determina plazo de resolución: 30 (true) vs 60 (false) días hábiles';
comment on column expedientes.es_programa_salud is 'Activa regla de opinión CIFRHS (60 días hábiles)';

-- Índices para consultas frecuentes
create index idx_expedientes_universidad on expedientes(universidad_id);
create index idx_expedientes_estado on expedientes(estado);
create index idx_expedientes_responsable on expedientes(responsable_id);
create index idx_expedientes_activo on expedientes(activo);

-- ============================================================
-- TABLA: reglas_plazo
-- ============================================================

create table reglas_plazo (
  id                  uuid primary key default uuid_generate_v4(),
  nombre              text not null,
  descripcion         text,
  tipo_tramite        tipo_tramite_enum,        -- NULL = aplica a todos
  dias                integer not null,          -- Negativo = días ANTES de fecha base
  tipo_dias           tipo_dias_enum not null default 'habiles',
  campo_fecha_base    text not null,             -- Nombre del campo en tabla expedientes
  condicion           jsonb,                     -- Condición opcional de activación
  activa              boolean not null default true,
  fundamento_legal    text,
  orden               integer not null default 0,
  created_by          uuid references usuarios(id),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

comment on table reglas_plazo is 'Motor de reglas de cálculo de plazos. Editable sin tocar código.';
comment on column reglas_plazo.condicion is 'JSONB: {"campo":"participa_acreditadora","valor":true} | {"campo":"fecha_prevencion","op":"no_nulo"}';
comment on column reglas_plazo.dias is 'Positivo = días después de fecha_base. Negativo = días ANTES (ej. notificar 30 días antes del ciclo)';

create index idx_reglas_activa on reglas_plazo(activa);
create index idx_reglas_tipo_tramite on reglas_plazo(tipo_tramite);

-- ============================================================
-- TABLA: etapas_expediente (fechas calculadas por expediente)
-- ============================================================

create table etapas_expediente (
  id                uuid primary key default uuid_generate_v4(),
  expediente_id     uuid not null references expedientes(id) on delete cascade,
  regla_id          uuid not null references reglas_plazo(id),
  nombre_etapa      text not null,
  fecha_base        date,
  fecha_calculada   date,
  fecha_real        date,
  estado_semaforo   semaforo_enum not null default 'gris',
  completada        boolean not null default false,
  notas             text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

comment on table etapas_expediente is 'Fechas calculadas por el motor de reglas para cada expediente';
comment on column etapas_expediente.fecha_calculada is 'Resultado del cálculo automático de días hábiles/naturales';
comment on column etapas_expediente.fecha_real is 'Fecha en que efectivamente ocurrió el evento (completada manualmente)';

create index idx_etapas_expediente on etapas_expediente(expediente_id);
create index idx_etapas_semaforo on etapas_expediente(estado_semaforo);
create index idx_etapas_completada on etapas_expediente(completada);
create index idx_etapas_fecha_calculada on etapas_expediente(fecha_calculada);

-- ============================================================
-- TABLA: dias_inhabiles
-- ============================================================

create table dias_inhabiles (
  id           uuid primary key default uuid_generate_v4(),
  fecha        date not null unique,
  descripcion  text not null,
  tipo         tipo_dia_inhabil_enum not null default 'nacional',
  created_by   uuid references usuarios(id),
  created_at   timestamptz not null default now()
);

comment on table dias_inhabiles is 'Catálogo editable de días inhábiles para el cálculo de plazos';

create index idx_dias_inhabiles_fecha on dias_inhabiles(fecha);

-- ============================================================
-- TABLA: alertas_config
-- ============================================================

create table alertas_config (
  id                       uuid primary key default uuid_generate_v4(),
  nombre                   text not null,
  dias_antes_habiles        integer[] not null default '{15,10,5,3,1}',
  canal                    canal_alerta_enum not null default 'email',
  destinatarios_adicionales text[] not null default '{}',
  activa                   boolean not null default true,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);

comment on table alertas_config is 'Configuración de umbrales y canales de alertas';

-- ============================================================
-- TABLA: alertas_log
-- ============================================================

create table alertas_log (
  id              uuid primary key default uuid_generate_v4(),
  etapa_id        uuid references etapas_expediente(id),
  expediente_id   uuid references expedientes(id),
  canal           text not null,
  destinatario    text not null,
  asunto          text,
  mensaje         text,
  enviada_en      timestamptz not null default now(),
  exitosa         boolean not null default true,
  error_detalle   text
);

comment on table alertas_log is 'Historial de alertas enviadas (auditoría)';

create index idx_alertas_log_expediente on alertas_log(expediente_id);
create index idx_alertas_log_enviada on alertas_log(enviada_en);

-- ============================================================
-- TABLA: documentos
-- ============================================================

create table documentos (
  id              uuid primary key default uuid_generate_v4(),
  expediente_id   uuid not null references expedientes(id) on delete cascade,
  nombre          text not null,
  tipo            text not null check (tipo in ('archivo', 'enlace')),
  url             text not null,
  subido_por      uuid references usuarios(id),
  created_at      timestamptz not null default now()
);

comment on table documentos is 'MVP: solo enlaces externos (SharePoint, Drive). v2: archivos en Supabase Storage';

create index idx_documentos_expediente on documentos(expediente_id);

-- ============================================================
-- TABLA: historial_cambios (auditoría)
-- ============================================================

create table historial_cambios (
  id              uuid primary key default uuid_generate_v4(),
  tabla           text not null,
  registro_id     uuid not null,
  campo           text not null,
  valor_anterior  jsonb,
  valor_nuevo     jsonb,
  usuario_id      uuid references usuarios(id),
  ip              text,
  created_at      timestamptz not null default now()
);

comment on table historial_cambios is 'Auditoría de todos los cambios del sistema. Inmutable.';

create index idx_historial_registro on historial_cambios(registro_id);
create index idx_historial_tabla on historial_cambios(tabla);
create index idx_historial_usuario on historial_cambios(usuario_id);
create index idx_historial_fecha on historial_cambios(created_at);

-- ============================================================
-- FUNCIÓN: updated_at automático
-- ============================================================

create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_universidades_updated_at
  before update on universidades
  for each row execute function set_updated_at();

create trigger trg_usuarios_updated_at
  before update on usuarios
  for each row execute function set_updated_at();

create trigger trg_expedientes_updated_at
  before update on expedientes
  for each row execute function set_updated_at();

create trigger trg_reglas_updated_at
  before update on reglas_plazo
  for each row execute function set_updated_at();

create trigger trg_etapas_updated_at
  before update on etapas_expediente
  for each row execute function set_updated_at();

-- ============================================================
-- FUNCIÓN: auditoría automática de expedientes
-- ============================================================

create or replace function audit_expediente_changes()
returns trigger language plpgsql security definer as $$
declare
  campo text;
  val_ant jsonb;
  val_nuevo jsonb;
  uid uuid;
begin
  -- Obtener usuario actual desde JWT
  uid := (select id from usuarios where id = auth.uid() limit 1);

  -- Recorrer columnas que cambiaron
  for campo in
    select key from jsonb_each(to_jsonb(new))
    where key not in ('updated_at','created_at')
  loop
    val_ant  := to_jsonb(old) -> campo;
    val_nuevo := to_jsonb(new) -> campo;
    if val_ant is distinct from val_nuevo then
      insert into historial_cambios(tabla, registro_id, campo, valor_anterior, valor_nuevo, usuario_id)
      values ('expedientes', new.id, campo, val_ant, val_nuevo, uid);
    end if;
  end loop;
  return new;
end;
$$;

create trigger trg_audit_expedientes
  after update on expedientes
  for each row execute function audit_expediente_changes();

-- ============================================================
-- FUNCIÓN: auditoría de reglas_plazo
-- ============================================================

create or replace function audit_regla_changes()
returns trigger language plpgsql security definer as $$
declare
  campo text;
  uid uuid;
begin
  uid := (select id from usuarios where id = auth.uid() limit 1);
  for campo in
    select key from jsonb_each(to_jsonb(new))
    where key not in ('updated_at')
  loop
    if (to_jsonb(old) -> campo) is distinct from (to_jsonb(new) -> campo) then
      insert into historial_cambios(tabla, registro_id, campo, valor_anterior, valor_nuevo, usuario_id)
      values ('reglas_plazo', new.id, campo, to_jsonb(old)->campo, to_jsonb(new)->campo, uid);
    end if;
  end loop;
  return new;
end;
$$;

create trigger trg_audit_reglas
  after update on reglas_plazo
  for each row execute function audit_regla_changes();

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================

alter table universidades         enable row level security;
alter table usuarios              enable row level security;
alter table expedientes           enable row level security;
alter table etapas_expediente     enable row level security;
alter table reglas_plazo          enable row level security;
alter table dias_inhabiles        enable row level security;
alter table alertas_config        enable row level security;
alter table alertas_log           enable row level security;
alter table documentos            enable row level security;
alter table historial_cambios     enable row level security;

-- Helper: obtener rol del usuario autenticado
create or replace function get_my_rol()
returns rol_usuario_enum language sql security definer stable as $$
  select rol from usuarios where id = auth.uid() limit 1;
$$;

-- Helper: obtener IDs de universidades del usuario
create or replace function get_my_universidad_ids()
returns uuid[] language sql security definer stable as $$
  select universidad_ids from usuarios where id = auth.uid() limit 1;
$$;

-- UNIVERSIDADES: todos pueden ver, solo admin puede modificar
create policy "uni_select" on universidades for select
  using (auth.role() = 'authenticated');

create policy "uni_all_admin" on universidades for all
  using (get_my_rol() = 'admin_juridica');

-- USUARIOS: cada quien ve su perfil; admin ve todos
create policy "usr_select_own" on usuarios for select
  using (id = auth.uid() or get_my_rol() = 'admin_juridica');

create policy "usr_update_own" on usuarios for update
  using (id = auth.uid());

create policy "usr_all_admin" on usuarios for all
  using (get_my_rol() = 'admin_juridica');

-- EXPEDIENTES: abogada ve los de sus universidades; admin ve todos
create policy "exp_select" on expedientes for select
  using (
    get_my_rol() = 'admin_juridica'
    or (
      get_my_rol() in ('abogada', 'consulta')
      and (
        array_length(get_my_universidad_ids(), 1) is null
        or universidad_id = any(get_my_universidad_ids())
      )
    )
  );

create policy "exp_insert" on expedientes for insert
  with check (get_my_rol() in ('admin_juridica', 'abogada'));

create policy "exp_update" on expedientes for update
  using (get_my_rol() in ('admin_juridica', 'abogada'));

-- ETAPAS: misma lógica que expedientes (via join)
create policy "etapas_select" on etapas_expediente for select
  using (
    exists (
      select 1 from expedientes e
      where e.id = etapas_expediente.expediente_id
      and (
        get_my_rol() = 'admin_juridica'
        or array_length(get_my_universidad_ids(), 1) is null
        or e.universidad_id = any(get_my_universidad_ids())
      )
    )
  );

create policy "etapas_write" on etapas_expediente for all
  using (get_my_rol() in ('admin_juridica', 'abogada'));

-- REGLAS: todos leen, solo admin modifica
create policy "reglas_select" on reglas_plazo for select
  using (auth.role() = 'authenticated');

create policy "reglas_write" on reglas_plazo for all
  using (get_my_rol() = 'admin_juridica');

-- DÍAS INHÁBILES: todos leen, solo admin modifica
create policy "dias_select" on dias_inhabiles for select
  using (auth.role() = 'authenticated');

create policy "dias_write" on dias_inhabiles for all
  using (get_my_rol() = 'admin_juridica');

-- ALERTAS CONFIG: todos leen, admin modifica
create policy "alertas_cfg_select" on alertas_config for select
  using (auth.role() = 'authenticated');

create policy "alertas_cfg_write" on alertas_config for all
  using (get_my_rol() = 'admin_juridica');

-- ALERTAS LOG, HISTORIAL, DOCUMENTOS: autenticados leen
create policy "alertas_log_select" on alertas_log for select
  using (auth.role() = 'authenticated');

create policy "historial_select" on historial_cambios for select
  using (auth.role() = 'authenticated');

create policy "docs_select" on documentos for select
  using (auth.role() = 'authenticated');

create policy "docs_write" on documentos for all
  using (get_my_rol() in ('admin_juridica', 'abogada'));

-- ============================================================
-- DATOS INICIALES: días inhábiles 2025-2026
-- ============================================================

insert into dias_inhabiles (fecha, descripcion, tipo) values
  ('2025-01-01', 'Año Nuevo',                           'nacional'),
  ('2025-02-03', 'Día de la Constitución (lunes)',       'nacional'),
  ('2025-03-17', 'Natalicio de Juárez (lunes)',          'nacional'),
  ('2025-04-17', 'Jueves Santo',                         'sep'),
  ('2025-04-18', 'Viernes Santo',                        'sep'),
  ('2025-05-01', 'Día del Trabajo',                      'nacional'),
  ('2025-09-16', 'Día de la Independencia',              'nacional'),
  ('2025-11-17', 'Revolución Mexicana (lunes)',           'nacional'),
  ('2025-12-25', 'Navidad',                              'nacional'),
  ('2026-01-01', 'Año Nuevo 2026',                       'nacional'),
  ('2026-02-02', 'Día de la Constitución (lunes)',        'nacional'),
  ('2026-03-16', 'Natalicio de Juárez (lunes)',           'nacional'),
  ('2026-04-02', 'Jueves Santo 2026',                    'sep'),
  ('2026-04-03', 'Viernes Santo 2026',                   'sep'),
  ('2026-05-01', 'Día del Trabajo 2026',                 'nacional'),
  ('2026-09-16', 'Día de la Independencia 2026',         'nacional'),
  ('2026-11-16', 'Revolución Mexicana (lunes) 2026',     'nacional'),
  ('2026-12-25', 'Navidad 2026',                         'nacional');

-- ============================================================
-- DATOS INICIALES: reglas de plazo (flujo RVOE documentado)
-- ============================================================

insert into reglas_plazo (nombre, descripcion, tipo_tramite, dias, tipo_dias, campo_fecha_base, condicion, activa, fundamento_legal, orden) values

-- NUEVO RVOE
('Límite presentación documentos iniciales',
 'Plazo máximo para presentar documentación ante la autoridad desde el inicio del trámite.',
 'nuevo_rvoe', 10, 'habiles', 'fecha_inicio', null, true, 'Art. 28 RVOE', 10),

('Plazo subsanación de prevención',
 'Días hábiles para subsanar prevención emitida por la autoridad. Corre desde que surte efectos la notificación (5 días hábiles después).',
 null, 5, 'habiles', 'fecha_prevencion',
 '{"campo":"fecha_prevencion","op":"no_nulo"}',
 true, 'Art. 31 RVOE', 20),

('Resolución revisión CON instancia acreditadora',
 'Plazo de la autoridad para emitir resolución cuando interviene instancia acreditadora. Inicia un día hábil posterior a la notificación.',
 'nuevo_rvoe', 30, 'habiles', 'fecha_notificacion',
 '{"campo":"participa_acreditadora","valor":true}',
 true, 'Art. 34 fracción I RVOE', 30),

('Resolución revisión SIN instancia acreditadora',
 'Plazo de la autoridad para emitir resolución sin instancia acreditadora. Inicia un día hábil posterior a la notificación.',
 'nuevo_rvoe', 60, 'habiles', 'fecha_notificacion',
 '{"campo":"participa_acreditadora","valor":false}',
 true, 'Art. 34 fracción II RVOE', 40),

('Opinión CIFRHS — programa de salud',
 'Plazo para la opinión de la Comisión Interinstitucional para la Formación de Recursos Humanos para la Salud.',
 'nuevo_rvoe', 60, 'habiles', 'fecha_notificacion',
 '{"campo":"es_programa_salud","valor":true}',
 true, 'Art. 35 RVOE', 50),

-- MODIFICACIÓN
('Modificación ante autoridad educativa',
 'Plazo de la autoridad para resolver modificaciones a RVOE existente.',
 'modificacion', 15, 'habiles', 'fecha_inicio', null, true, 'Art. 42 RVOE', 60),

-- CAMBIO POSTERIOR (sin nuevo RVOE)
('Notificar cambios sin nuevo RVOE — límite antes del ciclo',
 'La institución debe notificar cambios que no implican nuevo RVOE 30 días hábiles ANTES del inicio del siguiente ciclo escolar.',
 'cambio_posterior', -30, 'habiles', 'inicio_siguiente_ciclo', null, true, 'Art. 44 RVOE', 70),

('Autoridad notifica a terceros de cambios',
 'Plazo de la autoridad para notificar a terceros los cambios reportados.',
 'cambio_posterior', 5, 'habiles', 'fecha_notificacion', null, true, 'Art. 45 RVOE', 80),

-- REGLAMENTO ESCOLAR
('Envío reglamento escolar tras obtención RVOE',
 'La institución debe enviar el reglamento escolar dentro de los 20 días hábiles posteriores al otorgamiento del RVOE.',
 'reglamento_escolar', 20, 'habiles', 'fecha_obtencion_rvoe', null, true, 'Art. 51 RVOE', 90),

('Modificaciones al reglamento — límite antes de surtir efecto',
 'Las modificaciones al reglamento deben enviarse 30 días hábiles antes de que surtan efecto.',
 'reglamento_escolar', -30, 'habiles', 'inicio_siguiente_ciclo', null, true, 'Art. 52 RVOE', 100),

('SEP registra reglamento escolar',
 'Plazo de la SEP para registrar el reglamento escolar una vez recibido.',
 'reglamento_escolar', 5, 'habiles', 'fecha_presentacion', null, true, 'Art. 53 RVOE', 110),

('SEP previene sobre reglamento — plazo para atender',
 'Si la SEP emite prevención sobre el reglamento, la institución tiene 15 días hábiles para atenderla.',
 'reglamento_escolar', 15, 'habiles', 'fecha_prevencion',
 '{"campo":"fecha_prevencion","op":"no_nulo"}',
 true, 'Art. 54 RVOE', 120),

-- DOCUMENTACIÓN ESCOLAR
('Envío documentación escolar tras obtención RVOE',
 'La institución debe enviar la documentación escolar dentro de los 90 días hábiles posteriores a la obtención del RVOE.',
 'documentacion_escolar', 90, 'habiles', 'fecha_obtencion_rvoe', null, true, 'Art. 55 RVOE', 130),

('Autoridad autentica documentación escolar',
 'Plazo de la autoridad para autenticar la documentación escolar recibida.',
 'documentacion_escolar', 5, 'habiles', 'fecha_presentacion', null, true, 'Art. 56 RVOE', 140),

-- RETIRO DE RVOE
('SEP estudia solicitud de retiro',
 'Plazo de la SEP para analizar la solicitud de retiro de RVOE.',
 'retiro_rvoe', 10, 'habiles', 'fecha_inicio', null, true, 'Art. 60 RVOE', 150),

('Retiro RVOE — subsanación de prevención',
 'Si hay prevención en retiro, la institución tiene 5 días hábiles para subsanar.',
 'retiro_rvoe', 5, 'habiles', 'fecha_prevencion',
 '{"campo":"fecha_prevencion","op":"no_nulo"}',
 true, 'Art. 61 RVOE', 160),

('Retiro RVOE — resolución final',
 'Plazo de la autoridad para emitir resolución final en retiro de RVOE, tras subsanación.',
 'retiro_rvoe', 15, 'habiles', 'fecha_subsanacion', null, true, 'Art. 62 RVOE', 170);

-- ============================================================
-- DATOS INICIALES: configuración de alertas
-- ============================================================

insert into alertas_config (nombre, dias_antes_habiles, canal, activa) values
  ('Alertas estándar', '{15,10,5,3,1}', 'email', true);

-- ============================================================
-- FUNCIÓN: calcular días hábiles entre dos fechas
-- (usada por la API para validaciones server-side)
-- ============================================================

create or replace function dias_habiles_entre(fecha_a date, fecha_b date)
returns integer language plpgsql stable as $$
declare
  contador integer := 0;
  cursor_fecha date := fecha_a + 1;
  dia_semana integer;
  es_inhabil boolean;
begin
  if fecha_a >= fecha_b then return 0; end if;
  while cursor_fecha <= fecha_b loop
    dia_semana := extract(dow from cursor_fecha);
    if dia_semana not in (0, 6) then  -- No es sábado ni domingo
      select exists(select 1 from dias_inhabiles where fecha = cursor_fecha) into es_inhabil;
      if not es_inhabil then
        contador := contador + 1;
      end if;
    end if;
    cursor_fecha := cursor_fecha + 1;
  end loop;
  return contador;
end;
$$;

comment on function dias_habiles_entre is 'Cuenta días hábiles entre dos fechas, excluyendo fines de semana y tabla dias_inhabiles';

-- ============================================================
-- VISTA: expedientes con semáforo calculado
-- ============================================================

create or replace view v_expedientes_semaforo as
select
  e.id,
  e.folio,
  e.universidad_id,
  u.nombre as universidad_nombre,
  e.programa_academico,
  e.tipo_tramite,
  e.estado,
  e.responsable_id,
  us.nombre as responsable_nombre,
  e.activo,
  e.updated_at,
  -- Semáforo del expediente: el más crítico de sus etapas activas
  case
    when exists (
      select 1 from etapas_expediente et
      where et.expediente_id = e.id
        and not et.completada
        and et.estado_semaforo = 'rojo'
    ) then 'rojo'
    when exists (
      select 1 from etapas_expediente et
      where et.expediente_id = e.id
        and not et.completada
        and et.estado_semaforo = 'amarillo'
    ) then 'amarillo'
    when exists (
      select 1 from etapas_expediente et
      where et.expediente_id = e.id
        and not et.completada
        and et.estado_semaforo = 'verde'
    ) then 'verde'
    else 'gris'
  end as semaforo,
  -- Próxima fecha crítica
  (
    select min(et.fecha_calculada)
    from etapas_expediente et
    where et.expediente_id = e.id
      and not et.completada
      and et.fecha_calculada >= current_date
  ) as proxima_fecha
from expedientes e
join universidades u on u.id = e.universidad_id
left join usuarios us on us.id = e.responsable_id
where e.activo = true;

comment on view v_expedientes_semaforo is 'Vista de expedientes con semáforo calculado en tiempo real';
