// ============================================================
// RVOE·Track — Tipos del dominio
// ============================================================

export type TipoTramite =
  | 'nuevo_rvoe'
  | 'modificacion'
  | 'cambio_posterior'
  | 'retiro_rvoe'
  | 'reglamento_escolar'
  | 'documentacion_escolar'
  | 'otro'

export type EstadoExpediente =
  | 'borrador'
  | 'en_proceso'
  | 'en_prevencion'
  | 'en_revision'
  | 'resuelto'
  | 'cerrado'
  | 'archivado'

export type RolUsuario = 'admin_juridica' | 'abogada' | 'consulta'
export type TipoDias = 'habiles' | 'naturales'
export type Semaforo = 'verde' | 'amarillo' | 'rojo' | 'gris'
export type CanalAlerta = 'email' | 'teams' | 'ambos'
export type TipoDiaInhabil = 'nacional' | 'sep' | 'otro'

// ---- Entidades de base de datos ----

export interface Universidad {
  id: string
  nombre: string
  clave_sep?: string
  activa: boolean
  created_at: string
  updated_at: string
}

export interface Usuario {
  id: string
  nombre: string
  email: string
  rol: RolUsuario
  universidad_ids: string[]
  activo: boolean
  created_at: string
  updated_at: string
}

export interface Expediente {
  id: string
  folio: string
  universidad_id: string
  programa_academico: string
  tipo_tramite: TipoTramite
  autoridad: string
  estado: EstadoExpediente
  responsable_id?: string
  fecha_inicio?: string
  fecha_presentacion?: string
  fecha_notificacion?: string
  fecha_prevencion?: string
  fecha_subsanacion?: string
  fecha_resolucion?: string
  fecha_obtencion_rvoe?: string
  inicio_siguiente_ciclo?: string
  participa_acreditadora: boolean
  es_programa_salud: boolean
  comentarios?: string
  activo: boolean
  created_by?: string
  created_at: string
  updated_at: string
  // Relaciones expandidas
  universidad?: Universidad
  responsable?: Usuario
  etapas?: EtapaExpediente[]
}

export interface ReglaCondicion {
  campo: string
  op?: 'no_nulo' | 'es_nulo'
  valor?: boolean | string | number
}

export interface ReglasPlazo {
  id: string
  nombre: string
  descripcion?: string
  tipo_tramite?: TipoTramite
  dias: number
  tipo_dias: TipoDias
  campo_fecha_base: string
  condicion?: ReglaCondicion
  activa: boolean
  fundamento_legal?: string
  orden: number
  created_at: string
  updated_at: string
}

export interface EtapaExpediente {
  id: string
  expediente_id: string
  regla_id: string
  nombre_etapa: string
  fecha_base?: string
  fecha_calculada?: string
  fecha_real?: string
  estado_semaforo: Semaforo
  completada: boolean
  notas?: string
  created_at: string
  updated_at: string
  // Relación expandida
  regla?: ReglasPlazo
}

export interface DiaInhabil {
  id: string
  fecha: string
  descripcion: string
  tipo: TipoDiaInhabil
  created_at: string
}

export interface AlertasConfig {
  id: string
  nombre: string
  dias_antes_habiles: number[]
  canal: CanalAlerta
  destinatarios_adicionales: string[]
  activa: boolean
  created_at: string
  updated_at: string
}

export interface AlertaLog {
  id: string
  etapa_id?: string
  expediente_id?: string
  canal: string
  destinatario: string
  asunto?: string
  mensaje?: string
  enviada_en: string
  exitosa: boolean
  error_detalle?: string
}

export interface Documento {
  id: string
  expediente_id: string
  nombre: string
  tipo: 'archivo' | 'enlace'
  url: string
  subido_por?: string
  created_at: string
}

export interface HistorialCambio {
  id: string
  tabla: string
  registro_id: string
  campo: string
  valor_anterior?: unknown
  valor_nuevo?: unknown
  usuario_id?: string
  ip?: string
  created_at: string
  usuario?: Usuario
}

// ---- Vistas y DTOs ----

export interface ExpedienteConSemaforo extends Expediente {
  universidad_nombre: string
  responsable_nombre?: string
  semaforo: Semaforo
  proxima_fecha?: string
}

// ---- Etiquetas para UI ----

export const TIPO_TRAMITE_LABELS: Record<TipoTramite, string> = {
  nuevo_rvoe: 'Nuevo RVOE',
  modificacion: 'Modificación',
  cambio_posterior: 'Cambio posterior',
  retiro_rvoe: 'Retiro RVOE',
  reglamento_escolar: 'Reglamento escolar',
  documentacion_escolar: 'Documentación escolar',
  otro: 'Otro',
}

export const ESTADO_LABELS: Record<EstadoExpediente, string> = {
  borrador: 'Borrador',
  en_proceso: 'En proceso',
  en_prevencion: 'En prevención',
  en_revision: 'En revisión',
  resuelto: 'Resuelto',
  cerrado: 'Cerrado',
  archivado: 'Archivado',
}

export const ROL_LABELS: Record<RolUsuario, string> = {
  admin_juridica: 'Admin. Jurídica',
  abogada: 'Abogada',
  consulta: 'Consulta',
}

export const SEMAFORO_LABELS: Record<Semaforo, string> = {
  verde: 'Sin riesgo',
  amarillo: 'Próximo a vencer',
  rojo: 'Urgente / Vencido',
  gris: 'Sin fechas',
}
