'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const sb = createClient()

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const { error } = await sb.auth.signInWithPassword({ email, password })
    if (error) {
      toast.error('Credenciales incorrectas. Verifica tu correo y contraseña.')
    } else {
      router.push('/dashboard')
      router.refresh()
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-bg px-4">
      {/* Fondo con gradiente sutil */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 60% 50% at 50% 0%, rgba(79,142,247,0.08) 0%, transparent 70%)',
        }}
      />

      <div className="w-full max-w-sm relative">
        {/* Logo */}
        <div className="text-center mb-10">
          <h1
            className="font-head text-4xl font-semibold text-text mb-1"
            style={{ letterSpacing: '-0.5px' }}
          >
            RVOE
            <span style={{ color: 'var(--c-accent2)' }}>·</span>
            Track
          </h1>
          <p
            className="font-mono text-xs text-muted"
            style={{ letterSpacing: '0.8px', textTransform: 'uppercase' }}
          >
            Sistema Jurídico Corporativo
          </p>
        </div>

        {/* Formulario */}
        <div className="bg-surface border border-border rounded-lg p-8 shadow-card">
          <h2 className="font-head text-lg font-light text-text mb-6">
            Iniciar <span className="italic" style={{ color: 'var(--c-accent)' }}>sesión</span>
          </h2>

          <form onSubmit={handleLogin} className="flex flex-col gap-4">
            <div>
              <label
                className="block font-mono text-[10px] text-muted mb-1.5"
                style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}
              >
                Correo electrónico
              </label>
              <input
                type="email"
                className="input-base"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="abogada@corp.mx"
                required
                autoComplete="email"
              />
            </div>

            <div>
              <label
                className="block font-mono text-[10px] text-muted mb-1.5"
                style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}
              >
                Contraseña
              </label>
              <input
                type="password"
                className="input-base"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                autoComplete="current-password"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary justify-center mt-2 py-2.5 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? 'Verificando...' : 'Entrar al sistema'}
            </button>
          </form>
        </div>

        {/* Aviso legal */}
        <p className="text-center text-[11px] text-muted mt-6 leading-relaxed px-4">
          Sistema de uso exclusivo para el área jurídica corporativa.
          <br />
          Las fechas calculadas son orientativas y no sustituyen el criterio legal.
        </p>
      </div>
    </div>
  )
}
