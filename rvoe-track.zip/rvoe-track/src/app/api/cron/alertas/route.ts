// app/api/cron/alertas/route.ts
// Llamar diariamente desde Vercel Cron o servicio externo
// Protegido con CRON_SECRET en headers

import { NextResponse } from 'next/server'
import { procesarAlertas } from '@/lib/alertas'

export async function GET(request: Request) {
  // Verificar secret para evitar ejecuciones no autorizadas
  const authHeader = request.headers.get('authorization')
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  try {
    const resultado = await procesarAlertas()
    return NextResponse.json({
      ok: true,
      ...resultado,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: String(error) },
      { status: 500 }
    )
  }
}
