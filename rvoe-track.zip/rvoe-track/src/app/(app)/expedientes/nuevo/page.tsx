import { getUniversidades, getUsuarios, getReglas, getDiasInhabiles } from '@/lib/data'
import NuevoExpedienteForm from './NuevoExpedienteForm'

export default async function NuevoExpedientePage() {
  const [universidades, usuarios, reglas, inhabiles] = await Promise.all([
    getUniversidades(),
    getUsuarios(),
    getReglas(),
    getDiasInhabiles(),
  ])

  return (
    <NuevoExpedienteForm
      universidades={universidades}
      usuarios={usuarios}
      reglas={reglas}
      inhabiles={inhabiles}
    />
  )
}
