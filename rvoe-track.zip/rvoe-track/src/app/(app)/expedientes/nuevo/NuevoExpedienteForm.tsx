'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import { calcularEtapasExpediente, toISODate, fmtFecha } from '@/lib/fechas'
import { TIPO_TRAMITE_LABELS, ESTADO_LABELS, TipoTramite, EstadoExpediente } from '@/types'
import type { Universidad, Usuario, ReglasPlazo, DiaInhabil } from '@/types'
import PageHeader from '@/components/ui/PageHeader'
import SemaforoChip from '@/components/ui/SemaforoChip'
import { toast } from 'sonner'
import { ArrowLeft, Eye, Save } from 'lucide-react'
import Link from 'next/link'

interface Props {
  universidades: Universidad[]
  usuarios: Usuario[]
  reglas: ReglasPlazo[]
  inhabiles: DiaInhabil[]
}

type EtapaPreview = ReturnType<typeof calcularEtapasExpediente>[number]

export default function NuevoExpedienteForm({
  universidades, usuarios, reglas, inhabiles,
}: Props) {
  const router = useRouter()
  const sb = createClient()
  const [loading, setLoading] = useState(false)
  const [preview, setPreview] = useState<EtapaPreview[]>([])

  const [form, setForm] = useState({
    universidad_id: universidades[0]?.id ?? '',
    programa_academico: '',
    tipo_tramite: 'nuevo_rvoe' as TipoTramite,
    autoridad: 'SEP',
    estado: 'borrador' as EstadoExpediente,
    responsable_id: usuarios[0]?.id ?? '',
    fecha_inicio: toISODate(new Date()),
    fecha_presentacion: '',
    fecha_notificacion: '',
    fecha_prevencion: '',
    fecha_subsanacion: '',
    fecha_resolucion: '',
    fecha_obtencion_rvoe: '',
    inicio_siguiente_ciclo: '',
    participa_acreditadora: false,
    es_programa_salud: false,
    comentarios: '',
  })

  function set(field: string, value: unknown) {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  function handlePreview() {
    const etapas = calcularEtapasExpediente(
      form as any, reglas, inhabiles, toISODate(new Date())
    )
    setPreview(etapas)
    if (etapas.length === 0) {
      toast.info('Sin fechas calculables con los datos actuales. Complete más campos.')
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.programa_academico.trim()) {
      toast.error('El programa académico es obligatorio.')
      return
    }
    setLoading(true)

    // Generar folio
    const { count } = await sb.from('expedientes').select('*', { count: 'exact', head: true })
    const num = String((count ?? 0) + 1).padStart(3, '0')
    const folio = `RVOE-${new Date().getFullYear()}-${num}`

    const payload = {
      ...form,
      folio,
      activo: true,
      fecha_presentacion: form.fecha_presentacion || null,
      fecha_notificacion: form.fecha_notificacion || null,
      fecha_prevencion: form.fecha_prevencion || null,
      fecha_subsanacion: form.fecha_subsanacion || null,
      fecha_resolucion: form.fecha_resolucion || null,
      fecha_obtencion_rvoe: form.fecha_obtencion_rvoe || null,
      inicio_siguiente_ciclo: form.inicio_siguiente_ciclo || null,
      responsable_id: form.responsable_id || null,
    }

    const { data: exp, error } = await sb
      .from('expedientes')
      .insert(payload)
      .select()
      .single()

    if (error) {
      toast.error('Error al guardar: ' + error.message)
      setLoading(false)
      return
    }

    // Insertar etapas calculadas
    const etapas = calcularEtapasExpediente(
      exp as any, reglas, inhabiles, toISODate(new Date())
    )
    if (etapas.length > 0) {
      await sb.from('etapas_expediente').insert(
        etapas.map((et) => ({
          expediente_id: exp.id,
          regla_id: et.regla_id,
          nombre_etapa: et.nombre_etapa,
          fecha_base: et.fecha_base,
          fecha_calculada: et.fecha_calculada,
          estado_semaforo: et.estado_semaforo,
          completada: false,
        }))
      )
    }

    toast.success(`Expediente ${folio} creado con ${etapas.length} etapas calculadas.`)
    router.push(`/expedientes/${exp.id}`)
  }

  const Label = ({ children }: { children: React.ReactNode }) => (
    <label
      className="block font-mono text-[10px] text-muted mb-1.5"
      style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}
    >
      {children}
    </label>
  )

  return (
    <div>
      <PageHeader title="Nuevo" subtitle="expediente">
        <Link href="/expedientes" className="btn-ghost text-[12px]">
          <ArrowLeft size={13} />
          Cancelar
        </Link>
      </PageHeader>

      <form onSubmit={handleSubmit} className="px-7 pb-7">
        <div className="grid grid-cols-3 gap-5">
          {/* Formulario principal */}
          <div className="col-span-2 space-y-5">
            <div
              className="rounded-lg p-5"
              style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
            >
              <h3 className="font-head text-base font-light text-text mb-4">Datos del trámite</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Universidad</Label>
                  <select
                    className="input-base"
                    value={form.universidad_id}
                    onChange={(e) => set('universidad_id', e.target.value)}
                  >
                    {universidades.map((u) => (
                      <option key={u.id} value={u.id}>{u.nombre}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label>Tipo de trámite</Label>
                  <select
                    className="input-base"
                    value={form.tipo_tramite}
                    onChange={(e) => set('tipo_tramite', e.target.value)}
                  >
                    {Object.entries(TIPO_TRAMITE_LABELS).map(([v, l]) => (
                      <option key={v} value={v}>{l}</option>
                    ))}
                  </select>
                </div>
                <div className="col-span-2">
                  <Label>Programa académico *</Label>
                  <input
                    type="text"
                    className="input-base"
                    value={form.programa_academico}
                    onChange={(e) => set('programa_academico', e.target.value)}
                    placeholder="Nombre completo del programa"
                    required
                  />
                </div>
                <div>
                  <Label>Autoridad</Label>
                  <select
                    className="input-base"
                    value={form.autoridad}
                    onChange={(e) => set('autoridad', e.target.value)}
                  >
                    {['SEP','DGES','SEPE','COEPES','Otra'].map((a) => (
                      <option key={a}>{a}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label>Estado</Label>
                  <select
                    className="input-base"
                    value={form.estado}
                    onChange={(e) => set('estado', e.target.value)}
                  >
                    {Object.entries(ESTADO_LABELS).map(([v, l]) => (
                      <option key={v} value={v}>{l}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label>Responsable</Label>
                  <select
                    className="input-base"
                    value={form.responsable_id}
                    onChange={(e) => set('responsable_id', e.target.value)}
                  >
                    {usuarios.filter((u) => u.rol !== 'consulta').map((u) => (
                      <option key={u.id} value={u.id}>{u.nombre}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label>Fecha de inicio</Label>
                  <input
                    type="date"
                    className="input-base"
                    value={form.fecha_inicio}
                    onChange={(e) => set('fecha_inicio', e.target.value)}
                  />
                </div>
              </div>

              {/* Flags */}
              <div className="flex gap-6 mt-4 pt-4" style={{ borderTop: '1px solid var(--c-border)' }}>
                <label className="flex items-center gap-2 cursor-pointer text-[13px] text-muted hover:text-text transition-colors">
                  <input
                    type="checkbox"
                    checked={form.participa_acreditadora}
                    onChange={(e) => set('participa_acreditadora', e.target.checked)}
                    className="accent-accent"
                  />
                  Participa instancia acreditadora
                </label>
                <label className="flex items-center gap-2 cursor-pointer text-[13px] text-muted hover:text-text transition-colors">
                  <input
                    type="checkbox"
                    checked={form.es_programa_salud}
                    onChange={(e) => set('es_programa_salud', e.target.checked)}
                    className="accent-accent"
                  />
                  Programa del área de salud (CIFRHS)
                </label>
              </div>
            </div>

            {/* Fechas del proceso */}
            <div
              className="rounded-lg p-5"
              style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
            >
              <h3 className="font-head text-base font-light text-text mb-4">Fechas del proceso</h3>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { field: 'fecha_presentacion', label: 'Presentación ante autoridad' },
                  { field: 'fecha_notificacion', label: 'Notificación oficial' },
                  { field: 'fecha_prevencion', label: 'Prevención (si aplica)' },
                  { field: 'fecha_subsanacion', label: 'Subsanación de prevención' },
                  { field: 'fecha_resolucion', label: 'Resolución' },
                  { field: 'fecha_obtencion_rvoe', label: 'Obtención del RVOE' },
                  { field: 'inicio_siguiente_ciclo', label: 'Inicio siguiente ciclo escolar' },
                ].map(({ field, label }) => (
                  <div key={field}>
                    <Label>{label}</Label>
                    <input
                      type="date"
                      className="input-base"
                      value={(form as any)[field]}
                      onChange={(e) => set(field, e.target.value)}
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Comentarios */}
            <div
              className="rounded-lg p-5"
              style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
            >
              <Label>Comentarios</Label>
              <textarea
                className="input-base resize-none"
                rows={3}
                value={form.comentarios}
                onChange={(e) => set('comentarios', e.target.value)}
                placeholder="Observaciones del expediente..."
              />
            </div>

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={handlePreview}
                className="btn-ghost"
              >
                <Eye size={13} />
                Previsualizar fechas
              </button>
              <button type="submit" disabled={loading} className="btn-primary disabled:opacity-60">
                <Save size={13} />
                {loading ? 'Guardando...' : 'Guardar expediente'}
              </button>
            </div>
          </div>

          {/* Preview de etapas */}
          <div
            className="rounded-lg p-5 h-fit sticky top-4"
            style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
          >
            <h3 className="font-head text-base font-light text-text mb-4">
              Fechas calculadas
            </h3>
            {preview.length === 0 ? (
              <p className="text-[12px] text-muted leading-relaxed">
                Haz clic en <strong>"Previsualizar fechas"</strong> para ver las etapas que generará este expediente.
              </p>
            ) : (
              <div className="space-y-3">
                {preview.map((et, i) => (
                  <div
                    key={i}
                    className="pb-3"
                    style={{ borderBottom: '1px solid rgba(42,51,80,.4)' }}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-mono text-[11px] text-text leading-snug flex-1">
                        {et.nombre_etapa}
                      </p>
                      <SemaforoChip value={et.estado_semaforo} size="sm" showLabel={false} />
                    </div>
                    <p className="font-mono text-[11px] text-accent mt-1">
                      {fmtFecha(et.fecha_calculada)}
                    </p>
                    <p className="text-[10px] text-muted italic">{et.regla?.fundamento_legal}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </form>
    </div>
  )
}
