import { getExpedientes, getUniversidades } from '@/lib/data'
import PageHeader from '@/components/ui/PageHeader'
import SemaforoChip from '@/components/ui/SemaforoChip'
import Link from 'next/link'
import { TIPO_TRAMITE_LABELS, ESTADO_LABELS } from '@/types'
import { fmtFecha } from '@/lib/fechas'
import { PlusCircle, Eye } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function ExpedientesPage() {
  const [expedientes, universidades] = await Promise.all([
    getExpedientes(),
    getUniversidades(),
  ])

  const univMap = Object.fromEntries(universidades.map((u) => [u.id, u.nombre]))

  return (
    <div>
      <PageHeader title="Expedientes" subtitle="activos">
        <Link href="/expedientes/nuevo" className="btn-primary">
          <PlusCircle size={14} />
          Nuevo expediente
        </Link>
      </PageHeader>

      <div className="px-7 pb-7">
        <div
          className="rounded-lg overflow-hidden"
          style={{ border: '1px solid var(--c-border)', background: 'var(--c-card)' }}
        >
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr style={{ borderBottom: '1px solid var(--c-border)' }}>
                  {['Folio','Universidad','Programa','Tipo','Estado','Responsable','Semáforo',''].map(
                    (h) => (
                      <th
                        key={h}
                        className="text-left px-4 py-3 font-mono text-[10px] text-muted font-normal"
                        style={{ letterSpacing: '0.6px', textTransform: 'uppercase' }}
                      >
                        {h}
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {expedientes.length === 0 && (
                  <tr>
                    <td colSpan={8} className="text-center py-12 text-muted text-sm">
                      No hay expedientes activos. Crea el primero.
                    </td>
                  </tr>
                )}
                {expedientes.map((e) => (
                  <tr
                    key={e.id}
                    className="hover:bg-white/[0.02] transition-colors cursor-pointer"
                    style={{ borderBottom: '1px solid rgba(42,51,80,.5)' }}
                  >
                    <td className="px-4 py-3">
                      <span className="font-mono text-[12px] text-accent">{e.folio}</span>
                    </td>
                    <td className="px-4 py-3 text-[12px] text-muted max-w-[140px] truncate">
                      {univMap[e.universidad_id] ?? '—'}
                    </td>
                    <td className="px-4 py-3 text-[13px] max-w-[200px] truncate">
                      {e.programa_academico}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-mono
                          ${ e.tipo_tramite === 'nuevo_rvoe' ? 'badge-nuevo'
                            : e.tipo_tramite === 'modificacion' ? 'badge-mod'
                            : e.tipo_tramite === 'retiro_rvoe' ? 'badge-retiro'
                            : 'badge-otro'
                          }`}
                      >
                        {TIPO_TRAMITE_LABELS[e.tipo_tramite]}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono text-muted"
                        style={{ background: 'var(--c-surface)', border: '1px solid var(--c-border)' }}
                      >
                        {ESTADO_LABELS[e.estado]}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-[12px] text-muted">
                      {e.responsable_nombre ?? '—'}
                    </td>
                    <td className="px-4 py-3">
                      <SemaforoChip value={e.semaforo} size="sm" />
                    </td>
                    <td className="px-4 py-3">
                      <Link
                        href={`/expedientes/${e.id}`}
                        className="btn-ghost text-[12px] px-3 py-1.5"
                        onClick={(ev) => ev.stopPropagation()}
                      >
                        <Eye size={12} />
                        Ver
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
