import { getExpedienteById, getHistorial, getDocumentos } from '@/lib/data'
import { notFound } from 'next/navigation'
import PageHeader from '@/components/ui/PageHeader'
import SemaforoChip from '@/components/ui/SemaforoChip'
import { semaforoExpediente, fmtFecha } from '@/lib/fechas'
import { TIPO_TRAMITE_LABELS, ESTADO_LABELS } from '@/types'
import Link from 'next/link'
import { ArrowLeft, Edit, Clock, FileText, History } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function ExpedienteDetallePage({
  params,
}: {
  params: { id: string }
}) {
  const [exp, historial, docs] = await Promise.all([
    getExpedienteById(params.id),
    getHistorial(params.id),
    getDocumentos(params.id),
  ])

  if (!exp) notFound()

  const etapas = exp.etapas ?? []
  const sem = semaforoExpediente(etapas)

  const KV = ({ label, value }: { label: string; value?: string | null }) => (
    <div>
      <p
        className="font-mono text-[10px] text-muted mb-1"
        style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}
      >
        {label}
      </p>
      <p className="text-[13px] text-text">{value || '—'}</p>
    </div>
  )

  return (
    <div>
      <PageHeader title={exp.folio} subtitle={undefined}>
        <Link href="/expedientes" className="btn-ghost text-[12px]">
          <ArrowLeft size={13} />
          Volver
        </Link>
        <Link href={`/expedientes/${exp.id}/editar`} className="btn-primary text-[12px]">
          <Edit size={13} />
          Editar expediente
        </Link>
      </PageHeader>

      <div className="px-7 pb-7 grid grid-cols-3 gap-5">
        {/* Col izq: info */}
        <div className="col-span-2 space-y-5">
          {/* Cabecera del expediente */}
          <div
            className="rounded-lg p-5"
            style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
          >
            <div className="flex items-center gap-2 mb-4 flex-wrap">
              <SemaforoChip value={sem} />
              <span
                className={`inline-block px-2 py-0.5 rounded text-[11px] font-mono
                  ${ exp.tipo_tramite === 'nuevo_rvoe' ? 'badge-nuevo'
                    : exp.tipo_tramite === 'modificacion' ? 'badge-mod'
                    : exp.tipo_tramite === 'retiro_rvoe' ? 'badge-retiro'
                    : 'badge-otro'
                  }`}
              >
                {TIPO_TRAMITE_LABELS[exp.tipo_tramite]}
              </span>
              <span
                className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono text-muted"
                style={{ background: 'var(--c-surface)', border: '1px solid var(--c-border)' }}
              >
                {ESTADO_LABELS[exp.estado]}
              </span>
              {exp.es_programa_salud && (
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono bg-yellow/10 text-yellow border border-yellow/25">
                  Salud · CIFRHS
                </span>
              )}
              {exp.participa_acreditadora && (
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono bg-accent2/10 text-accent2 border border-accent2/25">
                  Con acreditadora
                </span>
              )}
            </div>

            <h2 className="font-head text-xl font-light text-text mb-5">
              {exp.programa_academico}
            </h2>

            <div className="grid grid-cols-2 gap-4">
              <KV label="Universidad" value={exp.universidad?.nombre} />
              <KV label="Autoridad" value={exp.autoridad} />
              <KV label="Responsable" value={exp.responsable?.nombre} />
              <KV label="Estado" value={ESTADO_LABELS[exp.estado]} />
              <KV label="Fecha inicio" value={fmtFecha(exp.fecha_inicio)} />
              <KV label="Fecha notificación" value={fmtFecha(exp.fecha_notificacion)} />
              <KV label="Fecha prevención" value={fmtFecha(exp.fecha_prevencion)} />
              <KV label="Fecha subsanación" value={fmtFecha(exp.fecha_subsanacion)} />
              <KV label="Fecha resolución" value={fmtFecha(exp.fecha_resolucion)} />
              <KV label="Obtención RVOE" value={fmtFecha(exp.fecha_obtencion_rvoe)} />
              <KV label="Presentación" value={fmtFecha(exp.fecha_presentacion)} />
              <KV label="Inicio ciclo escolar" value={fmtFecha(exp.inicio_siguiente_ciclo)} />
            </div>

            {exp.comentarios && (
              <div className="mt-4 pt-4" style={{ borderTop: '1px solid var(--c-border)' }}>
                <p
                  className="font-mono text-[10px] text-muted mb-1"
                  style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}
                >
                  Comentarios
                </p>
                <p className="text-[13px] text-muted leading-relaxed">{exp.comentarios}</p>
              </div>
            )}
          </div>

          {/* Documentos */}
          <div
            className="rounded-lg p-5"
            style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-head text-base font-light flex items-center gap-2">
                <FileText size={14} className="text-muted" />
                Documentos
              </h3>
            </div>
            {docs.length === 0 ? (
              <p className="text-[12px] text-muted">Sin documentos adjuntos.</p>
            ) : (
              <div className="space-y-2">
                {docs.map((d) => (
                  <a
                    key={d.id}
                    href={d.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-[13px] text-accent hover:underline"
                  >
                    <FileText size={12} />
                    {d.nombre}
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Historial */}
          <div
            className="rounded-lg p-5"
            style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
          >
            <h3 className="font-head text-base font-light flex items-center gap-2 mb-4">
              <History size={14} className="text-muted" />
              Historial de cambios
            </h3>
            {historial.length === 0 ? (
              <p className="text-[12px] text-muted">Sin cambios registrados.</p>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {historial.slice(0, 20).map((h) => (
                  <div
                    key={h.id}
                    className="flex items-start gap-3 text-[12px] py-2"
                    style={{ borderBottom: '1px solid rgba(42,51,80,.4)' }}
                  >
                    <span className="font-mono text-[10px] text-muted mt-0.5 flex-shrink-0 w-32">
                      {new Date(h.created_at).toLocaleDateString('es-MX', {
                        day: '2-digit', month: '2-digit', year: 'numeric',
                        hour: '2-digit', minute: '2-digit',
                      })}
                    </span>
                    <span className="text-muted">
                      <span className="text-text">{h.usuario?.nombre ?? 'Sistema'}</span>
                      {' '}cambió{' '}
                      <span className="font-mono text-accent text-[11px]">{h.campo}</span>
                      {' '}de{' '}
                      <span className="text-red/80">{JSON.stringify(h.valor_anterior) ?? '—'}</span>
                      {' '}a{' '}
                      <span className="text-green/80">{JSON.stringify(h.valor_nuevo) ?? '—'}</span>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Col der: línea de tiempo */}
        <div
          className="rounded-lg p-5 h-fit"
          style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
        >
          <h3 className="font-head text-base font-light flex items-center gap-2 mb-5">
            <Clock size={14} className="text-muted" />
            Línea de tiempo
          </h3>

          {etapas.length === 0 ? (
            <p className="text-[12px] text-muted leading-relaxed">
              Sin etapas calculadas. Complete las fechas del expediente para activar el motor de reglas.
            </p>
          ) : (
            <div className="relative pl-5">
              {/* Línea vertical */}
              <div
                className="absolute left-[7px] top-0 bottom-0 w-px"
                style={{ background: 'var(--c-border)' }}
              />

              {etapas.map((et) => {
                const dotColor =
                  et.completada ? 'var(--c-green)'
                  : et.estado_semaforo === 'rojo' ? 'var(--c-red)'
                  : et.estado_semaforo === 'amarillo' ? 'var(--c-yellow)'
                  : et.estado_semaforo === 'verde' ? 'var(--c-green)'
                  : 'var(--c-muted)'

                return (
                  <div key={et.id} className="relative mb-5">
                    {/* Dot */}
                    <div
                      className="absolute -left-5 top-1 w-2.5 h-2.5 rounded-full z-10"
                      style={{
                        background: dotColor,
                        border: '2px solid var(--c-bg)',
                        marginLeft: '2px',
                      }}
                    />
                    <p className="font-mono text-[10px] text-muted mb-0.5">
                      {fmtFecha(et.fecha_calculada)}
                    </p>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <p className="text-[12px] text-text leading-snug">{et.nombre_etapa}</p>
                      <SemaforoChip
                        value={et.completada ? 'verde' : et.estado_semaforo}
                        size="sm"
                        showLabel={false}
                      />
                    </div>
                    <p className="text-[10px] text-muted italic mt-0.5">
                      {et.regla?.fundamento_legal}
                    </p>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
