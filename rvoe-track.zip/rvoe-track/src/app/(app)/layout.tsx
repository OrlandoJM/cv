import Sidebar from '@/components/ui/Sidebar'
import LegalBanner from '@/components/ui/LegalBanner'

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden bg-bg">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-y-auto">
          <LegalBanner />
          {children}
        </main>
      </div>
    </div>
  )
}
