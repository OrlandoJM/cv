'use client'
import { useState } from 'react'
import { ReglasPlazo, TIPO_TRAMITE_LABELS } from '@/types'
import { toggleRegla } from '@/lib/data'
import { toast } from 'sonner'
import { useRouter } from 'next/navigation'

export default function ReglasList({ reglas: initial }: { reglas: ReglasPlazo[] }) {
  const [reglas, setReglas] = useState(initial)
  const router = useRouter()

  async function handleToggle(id: string, activa: boolean) {
    try {
      await toggleRegla(id, activa)
      setReglas((prev) => prev.map((r) => (r.id === id ? { ...r, activa } : r)))
      toast.success(`Regla ${activa ? 'activada' : 'desactivada'}. Cambio registrado en auditoría.`)
      router.refresh()
    } catch {
      toast.error('Error al actualizar la regla.')
    }
  }

  return (
    <div className="space-y-3">
      <div
        className="flex items-start gap-2 p-3 rounded text-[11px] text-muted leading-relaxed"
        style={{ background: 'rgba(79,142,247,.08)', border: '1px solid rgba(79,142,247,.2)' }}
      >
        <span className="mt-0.5 flex-shrink-0">⚖️</span>
        <span>
          Los cambios a reglas se registran automáticamente en auditoría.
          Desactivar una regla no la elimina — puede reactivarse en cualquier momento.
          Para activarse, los cambios se aplican a nuevos expedientes y recálculos manuales.
        </span>
      </div>

      {reglas.map((r) => (
        <div
          key={r.id}
          className="flex items-center gap-4 p-4 rounded-lg transition-all"
          style={{
            background: 'var(--c-card)',
            border: `1px solid ${r.activa ? 'var(--c-border)' : 'rgba(42,51,80,.4)'}`,
            opacity: r.activa ? 1 : 0.6,
          }}
        >
          {/* Toggle */}
          <button
            onClick={() => handleToggle(r.id, !r.activa)}
            className="flex-shrink-0 relative w-9 h-5 rounded-full transition-colors"
            style={{ background: r.activa ? 'var(--c-accent)' : 'var(--c-border)' }}
            title={r.activa ? 'Desactivar regla' : 'Activar regla'}
          >
            <span
              className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all"
              style={{ left: r.activa ? '18px' : '2px' }}
            />
          </button>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <p className="text-[13px] text-text mb-0.5">{r.nombre}</p>
            <p className="font-mono text-[10px] text-muted">
              {r.dias > 0 ? '+' : ''}{r.dias} días {r.tipo_dias}
              {' · '}base: <span className="text-accent">{r.campo_fecha_base.replace(/_/g, ' ')}</span>
              {r.condicion && (
                <span>
                  {' · si '}
                  <span className="text-accent2">{r.condicion.campo.replace(/_/g, ' ')}</span>
                  {r.condicion.valor !== undefined && ` = ${String(r.condicion.valor)}`}
                  {r.condicion.op && ` (${r.condicion.op.replace('_', ' ')})`}
                </span>
              )}
              {' · '}{r.fundamento_legal}
            </p>
          </div>

          {/* Badge tipo */}
          <span
            className="flex-shrink-0 inline-block px-2 py-0.5 rounded text-[10px] font-mono text-muted"
            style={{ background: 'var(--c-surface)', border: '1px solid var(--c-border)' }}
          >
            {r.tipo_tramite ? TIPO_TRAMITE_LABELS[r.tipo_tramite] : 'General'}
          </span>

          {/* Orden */}
          <span className="flex-shrink-0 font-mono text-[10px] text-muted w-8 text-right">
            #{r.orden}
          </span>
        </div>
      ))}
    </div>
  )
}
