import { getReglas } from '@/lib/data'
import PageHeader from '@/components/ui/PageHeader'
import ReglasList from './ReglasList'

export const dynamic = 'force-dynamic'

export default async function ReglasPage() {
  const reglas = await getReglas()
  return (
    <div>
      <PageHeader title="Reglas de" subtitle="plazo" />
      <div className="px-7 pb-7">
        <ReglasList reglas={reglas} />
      </div>
    </div>
  )
}
