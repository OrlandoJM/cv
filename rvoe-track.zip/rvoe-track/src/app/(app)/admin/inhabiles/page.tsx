import { getDiasInhabiles } from '@/lib/data'
import PageHeader from '@/components/ui/PageHeader'
import DiasInhabilesClient from './DiasInhabilesClient'

export const dynamic = 'force-dynamic'

export default async function DiasInhabilesPage() {
  const dias = await getDiasInhabiles()
  return (
    <div>
      <PageHeader title="Días" subtitle="inhábiles" />
      <div className="px-7 pb-7">
        <DiasInhabilesClient dias={dias} />
      </div>
    </div>
  )
}
