'use client'
import { useState } from 'react'
import { DiaInhabil, TipoDiaInhabil } from '@/types'
import { insertDiaInhabil, deleteDiaInhabil } from '@/lib/data'
import { fmtFecha } from '@/lib/fechas'
import { toast } from 'sonner'
import { PlusCircle, Trash2 } from 'lucide-react'

export default function DiasInhabilesClient({ dias: initial }: { dias: DiaInhabil[] }) {
  const [dias, setDias] = useState(initial)
  const [form, setForm] = useState({ fecha: '', descripcion: '', tipo: 'nacional' as TipoDiaInhabil })
  const [adding, setAdding] = useState(false)

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault()
    if (!form.fecha || !form.descripcion.trim()) {
      toast.error('Completa todos los campos.')
      return
    }
    if (dias.some((d) => d.fecha === form.fecha)) {
      toast.error('Ya existe un día inhábil para esa fecha.')
      return
    }
    try {
      const nuevo = await insertDiaInhabil(form)
      setDias((prev) => [...prev, nuevo].sort((a, b) => a.fecha.localeCompare(b.fecha)))
      setForm({ fecha: '', descripcion: '', tipo: 'nacional' })
      setAdding(false)
      toast.success('Día inhábil agregado.')
    } catch {
      toast.error('Error al guardar.')
    }
  }

  async function handleDelete(id: string, desc: string) {
    if (!confirm(`¿Eliminar "${desc}" del catálogo de días inhábiles?`)) return
    try {
      await deleteDiaInhabil(id)
      setDias((prev) => prev.filter((d) => d.id !== id))
      toast.success('Día eliminado del catálogo.')
    } catch {
      toast.error('Error al eliminar.')
    }
  }

  const tipoColor: Record<TipoDiaInhabil, string> = {
    nacional: 'var(--c-accent)',
    sep: 'var(--c-accent2)',
    otro: 'var(--c-muted)',
  }

  const Label = ({ children }: { children: React.ReactNode }) => (
    <label className="block font-mono text-[10px] text-muted mb-1.5" style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}>
      {children}
    </label>
  )

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-[13px] text-muted">
          {dias.length} días inhábiles registrados. Modificar este catálogo afecta todos los cálculos de fechas.
        </p>
        <button onClick={() => setAdding(!adding)} className="btn-primary text-[12px]">
          <PlusCircle size={13} />
          Agregar día
        </button>
      </div>

      {/* Formulario de alta */}
      {adding && (
        <form
          onSubmit={handleAdd}
          className="rounded-lg p-5"
          style={{ background: 'var(--c-card)', border: '1px solid var(--c-accent)/30', borderColor: 'rgba(79,142,247,.3)' }}
        >
          <h3 className="font-head text-base font-light text-text mb-4">Agregar día inhábil</h3>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div>
              <Label>Fecha</Label>
              <input
                type="date"
                className="input-base"
                value={form.fecha}
                onChange={(e) => setForm((p) => ({ ...p, fecha: e.target.value }))}
                required
              />
            </div>
            <div>
              <Label>Descripción</Label>
              <input
                type="text"
                className="input-base"
                value={form.descripcion}
                onChange={(e) => setForm((p) => ({ ...p, descripcion: e.target.value }))}
                placeholder="Ej. Asueto SEP 2026"
                required
              />
            </div>
            <div>
              <Label>Tipo</Label>
              <select
                className="input-base"
                value={form.tipo}
                onChange={(e) => setForm((p) => ({ ...p, tipo: e.target.value as TipoDiaInhabil }))}
              >
                <option value="nacional">Nacional</option>
                <option value="sep">SEP</option>
                <option value="otro">Otro</option>
              </select>
            </div>
          </div>
          <div className="flex gap-3">
            <button type="submit" className="btn-primary text-[12px]">Guardar</button>
            <button type="button" onClick={() => setAdding(false)} className="btn-ghost text-[12px]">Cancelar</button>
          </div>
        </form>
      )}

      {/* Grid de días */}
      <div className="grid grid-cols-3 gap-3">
        {dias.map((d) => (
          <div
            key={d.id}
            className="flex items-center justify-between rounded-lg p-3.5"
            style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
          >
            <div>
              <p className="font-mono text-[12px] mb-0.5" style={{ color: tipoColor[d.tipo] }}>
                {fmtFecha(d.fecha)}
              </p>
              <p className="text-[12px] text-text mb-1">{d.descripcion}</p>
              <span
                className="inline-block font-mono text-[9px] px-1.5 py-0.5 rounded text-muted"
                style={{ background: 'var(--c-surface)', border: '1px solid var(--c-border)' }}
              >
                {d.tipo}
              </span>
            </div>
            <button
              onClick={() => handleDelete(d.id, d.descripcion)}
              className="btn-danger p-1.5 ml-2 flex-shrink-0"
              title="Eliminar"
            >
              <Trash2 size={12} />
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
