import { getUsuarios, getUniversidades } from '@/lib/data'
import PageHeader from '@/components/ui/PageHeader'
import { ROL_LABELS } from '@/types'

export const dynamic = 'force-dynamic'

export default async function UsuariosPage() {
  const [usuarios, universidades] = await Promise.all([getUsuarios(), getUniversidades()])
  const univMap = Object.fromEntries(universidades.map((u) => [u.id, u.nombre]))

  return (
    <div>
      <PageHeader title="Gestión de" subtitle="usuarios" />
      <div className="px-7 pb-7">
        <div
          className="rounded-lg overflow-hidden"
          style={{ border: '1px solid var(--c-border)', background: 'var(--c-card)' }}
        >
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr style={{ borderBottom: '1px solid var(--c-border)' }}>
                  {['Nombre','Correo','Rol','Universidades','Estado'].map((h) => (
                    <th
                      key={h}
                      className="text-left px-4 py-3 font-mono text-[10px] text-muted font-normal"
                      style={{ letterSpacing: '0.6px', textTransform: 'uppercase' }}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {usuarios.map((u) => (
                  <tr
                    key={u.id}
                    style={{ borderBottom: '1px solid rgba(42,51,80,.5)' }}
                  >
                    <td className="px-4 py-3 text-[13px] text-text">{u.nombre}</td>
                    <td className="px-4 py-3 font-mono text-[12px] text-muted">{u.email}</td>
                    <td className="px-4 py-3">
                      <span
                        className="inline-block px-2 py-0.5 rounded font-mono text-[11px] text-muted"
                        style={{ background: 'var(--c-surface)', border: '1px solid var(--c-border)' }}
                      >
                        {ROL_LABELS[u.rol]}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-[12px] text-muted">
                      {u.universidad_ids.length === 0
                        ? 'Todas'
                        : u.universidad_ids.map((id) => univMap[id] ?? id).join(', ')}
                    </td>
                    <td className="px-4 py-3">
                      {u.activo ? (
                        <span className="inline-flex items-center gap-1.5 font-mono text-[11px] text-green">
                          <span className="w-1.5 h-1.5 rounded-full bg-green" />
                          Activo
                        </span>
                      ) : (
                        <span className="text-[11px] text-muted">Inactivo</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <p className="text-[11px] text-muted mt-3 italic">
          Para crear usuarios, ve a Supabase → Authentication → Users → Invite user,
          luego asigna el rol desde la tabla usuarios.
        </p>
      </div>
    </div>
  )
}
