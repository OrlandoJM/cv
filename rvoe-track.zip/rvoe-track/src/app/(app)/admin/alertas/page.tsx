import { getAlertasConfig, getAlertasLog } from '@/lib/data'
import PageHeader from '@/components/ui/PageHeader'
import { fmtFecha } from '@/lib/fechas'
import { CheckCircle, XCircle } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function AlertasPage() {
  const [configs, logs] = await Promise.all([
    getAlertasConfig(),
    getAlertasLog(undefined, 50),
  ])

  const config = configs[0]

  return (
    <div>
      <PageHeader title="Configuración de" subtitle="alertas" />
      <div className="px-7 pb-7 space-y-5">

        {/* Configuración actual */}
        {config && (
          <div
            className="rounded-lg p-5"
            style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
          >
            <h3 className="font-head text-base font-light text-text mb-4">
              Configuración activa
            </h3>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="font-mono text-[10px] text-muted mb-1.5" style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}>
                  Días hábiles de aviso
                </p>
                <div className="flex gap-2 flex-wrap">
                  {config.dias_antes_habiles.map((d) => (
                    <span
                      key={d}
                      className="font-mono text-[12px] px-2 py-1 rounded"
                      style={{
                        background: d <= 3 ? 'rgba(245,90,90,.15)' : d <= 5 ? 'rgba(245,200,66,.15)' : 'rgba(79,142,247,.15)',
                        color: d <= 3 ? 'var(--c-red)' : d <= 5 ? 'var(--c-yellow)' : 'var(--c-accent)',
                        border: `1px solid ${d <= 3 ? 'rgba(245,90,90,.3)' : d <= 5 ? 'rgba(245,200,66,.3)' : 'rgba(79,142,247,.3)'}`,
                      }}
                    >
                      {d}d
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <p className="font-mono text-[10px] text-muted mb-1.5" style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}>
                  Canal
                </p>
                <p className="text-[13px] text-text capitalize">{config.canal}</p>
              </div>
              <div>
                <p className="font-mono text-[10px] text-muted mb-1.5" style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}>
                  Estado
                </p>
                <span
                  className={`inline-flex items-center gap-1.5 font-mono text-[11px] ${config.activa ? 'text-green' : 'text-muted'}`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${config.activa ? 'bg-green' : 'bg-muted'}`} />
                  {config.activa ? 'Activa' : 'Inactiva'}
                </span>
              </div>
            </div>
            <p className="text-[11px] text-muted mt-4 italic">
              Las alertas se procesan diariamente. Para modificar umbrales o destinatarios,
              actualiza directamente en Supabase → alertas_config.
            </p>
          </div>
        )}

        {/* Historial de alertas */}
        <div
          className="rounded-lg overflow-hidden"
          style={{ border: '1px solid var(--c-border)', background: 'var(--c-card)' }}
        >
          <div className="px-5 py-4" style={{ borderBottom: '1px solid var(--c-border)' }}>
            <h3 className="font-head text-base font-light text-text">Historial de alertas enviadas</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr style={{ borderBottom: '1px solid var(--c-border)' }}>
                  {['Fecha','Canal','Destinatario','Asunto','Estado'].map((h) => (
                    <th
                      key={h}
                      className="text-left px-4 py-3 font-mono text-[10px] text-muted font-normal"
                      style={{ letterSpacing: '0.6px', textTransform: 'uppercase' }}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {logs.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-8 text-muted text-sm">
                      Sin alertas enviadas aún.
                    </td>
                  </tr>
                )}
                {logs.map((l) => (
                  <tr key={l.id} style={{ borderBottom: '1px solid rgba(42,51,80,.5)' }}>
                    <td className="px-4 py-3 font-mono text-[11px] text-muted">
                      {new Date(l.enviada_en).toLocaleDateString('es-MX', {
                        day: '2-digit', month: '2-digit', year: 'numeric',
                        hour: '2-digit', minute: '2-digit',
                      })}
                    </td>
                    <td className="px-4 py-3 font-mono text-[11px] text-muted capitalize">{l.canal}</td>
                    <td className="px-4 py-3 font-mono text-[12px] text-muted">{l.destinatario}</td>
                    <td className="px-4 py-3 text-[12px] text-text max-w-[240px] truncate">{l.asunto ?? '—'}</td>
                    <td className="px-4 py-3">
                      {l.exitosa ? (
                        <span className="flex items-center gap-1 text-green text-[11px]">
                          <CheckCircle size={11} /> Enviada
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-red text-[11px]">
                          <XCircle size={11} /> Error
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
