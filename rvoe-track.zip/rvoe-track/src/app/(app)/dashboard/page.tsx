import { getDashboardStats } from '@/lib/data'
import { getUniversidades } from '@/lib/data'
import PageHeader from '@/components/ui/PageHeader'
import SemaforoChip from '@/components/ui/SemaforoChip'
import { fmtFecha } from '@/lib/fechas'
import { TIPO_TRAMITE_LABELS } from '@/types'
import Link from 'next/link'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const [{ total, porSemaforo, proximas, expedientes }, universidades] =
    await Promise.all([getDashboardStats(), getUniversidades()])

  return (
    <div>
      <PageHeader title="Dashboard" subtitle="general" />

      <div className="px-7 pb-7 space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: 'Expedientes activos', value: total, color: 'var(--c-accent)' },
            { label: 'Semáforo rojo', value: porSemaforo.rojo, color: 'var(--c-red)' },
            { label: 'Semáforo amarillo', value: porSemaforo.amarillo, color: 'var(--c-yellow)' },
            { label: 'Semáforo verde', value: porSemaforo.verde, color: 'var(--c-green)' },
          ].map((s) => (
            <div
              key={s.label}
              className="rounded-lg p-5"
              style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
            >
              <p
                className="font-mono text-[10px] text-muted mb-2"
                style={{ letterSpacing: '0.6px', textTransform: 'uppercase' }}
              >
                {s.label}
              </p>
              <p className="font-head text-[32px] font-semibold leading-none" style={{ color: s.color }}>
                {s.value}
              </p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-5">
          {/* Por universidad */}
          <div
            className="rounded-lg p-5"
            style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
          >
            <h2 className="font-head text-base font-light text-text mb-4">Por universidad</h2>
            {universidades.map((u) => {
              const exps = expedientes.filter((e) => e.universidad_id === u.id)
              const sem = exps.some((e) => e.semaforo === 'rojo')
                ? 'rojo'
                : exps.some((e) => e.semaforo === 'amarillo')
                ? 'amarillo'
                : exps.length > 0 ? 'verde' : 'gris'
              return (
                <div
                  key={u.id}
                  className="flex items-center justify-between py-3"
                  style={{ borderBottom: '1px solid var(--c-border)' }}
                >
                  <div>
                    <p className="text-[13px] text-text mb-0.5">{u.nombre}</p>
                    <p className="font-mono text-[10px] text-muted">
                      {u.clave_sep} · {exps.length} expediente{exps.length !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <SemaforoChip value={sem} size="sm" />
                </div>
              )
            })}
          </div>

          {/* Próximas fechas */}
          <div
            className="rounded-lg p-5"
            style={{ background: 'var(--c-card)', border: '1px solid var(--c-border)' }}
          >
            <h2 className="font-head text-base font-light text-text mb-4">
              Próximas fechas clave
            </h2>
            {proximas.length === 0 ? (
              <p className="text-[13px] text-muted">Sin fechas próximas calculadas.</p>
            ) : (
              proximas.map((e) => (
                <Link
                  key={e.id}
                  href={`/expedientes/${e.id}`}
                  className="flex items-start justify-between gap-3 py-2.5 hover:opacity-80 transition-opacity"
                  style={{ borderBottom: '1px solid rgba(42,51,80,.4)' }}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-[10px] text-muted mb-0.5">
                      {e.folio} · {e.universidad_nombre.split(' ').slice(0, 2).join(' ')}
                    </p>
                    <p className="text-[13px] text-text truncate">{e.programa_academico}</p>
                    <p className="font-mono text-[10px] text-muted mt-0.5">
                      {TIPO_TRAMITE_LABELS[e.tipo_tramite]}
                    </p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="font-mono text-[12px] text-text mb-1">
                      {fmtFecha(e.proxima_fecha ?? undefined)}
                    </p>
                    <SemaforoChip value={e.semaforo} size="sm" />
                  </div>
                </Link>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
