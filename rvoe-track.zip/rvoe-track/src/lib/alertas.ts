// ============================================================
// RVOE·Track — Servicio de alertas por correo (Resend)
// lib/alertas.ts
// ============================================================
import { Resend } from 'resend'
import { createClient } from './supabase'
import { AlertasConfig, EtapaExpediente, Expediente, Usuario } from '@/types'
import { calcularFechasAlerta, diasHabilesRestantes, fmtFecha, toISODate } from './fechas'

const resend = new Resend(process.env.RESEND_API_KEY)
const FROM = process.env.RESEND_FROM_EMAIL ?? 'rvoe@corp.mx'
const APP_URL = process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000'

// ============================================================
// Plantilla HTML para correo de alerta
// ============================================================

function plantillaAlerta(params: {
  expedienteId: string
  folio: string
  programa: string
  universidad: string
  etapaNombre: string
  fechaLimite: string
  diasRestantes: number
  fundamento: string
}): { subject: string; html: string } {
  const urgencia =
    params.diasRestantes <= 1
      ? '🔴 URGENTE'
      : params.diasRestantes <= 3
      ? '🔴 Crítico'
      : params.diasRestantes <= 5
      ? '🟡 Atención requerida'
      : '🟡 Próximo vencimiento'

  const subject = `${urgencia} — ${params.etapaNombre} | ${params.folio}`

  const html = `
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"/>
<style>
  body { font-family: 'Segoe UI', Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 20px; }
  .container { max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 16px rgba(0,0,0,0.08); }
  .header { background: #0f1117; padding: 24px 32px; }
  .header h1 { color: #4f8ef7; font-size: 20px; margin: 0; letter-spacing: -0.3px; }
  .header span { color: #7a85a3; font-size: 12px; }
  .body { padding: 32px; }
  .alerta-box { background: ${params.diasRestantes <= 3 ? '#fff5f5' : '#fffbeb'}; border: 1px solid ${params.diasRestantes <= 3 ? '#fecaca' : '#fde68a'}; border-radius: 8px; padding: 16px 20px; margin-bottom: 24px; }
  .alerta-box .dias { font-size: 36px; font-weight: 700; color: ${params.diasRestantes <= 3 ? '#ef4444' : '#d97706'}; line-height: 1; }
  .alerta-box .label { font-size: 13px; color: #6b7280; margin-top: 4px; }
  .info-row { display: flex; margin-bottom: 12px; }
  .info-label { font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; width: 130px; flex-shrink: 0; padding-top: 2px; }
  .info-value { font-size: 14px; color: #111827; }
  .fundamento { font-size: 11px; color: #9ca3af; font-style: italic; margin-top: 16px; padding-top: 16px; border-top: 1px solid #e5e7eb; }
  .cta { display: inline-block; background: #4f8ef7; color: #fff; text-decoration: none; padding: 10px 20px; border-radius: 6px; font-size: 13px; font-weight: 500; margin-top: 20px; }
  .footer { background: #f9fafb; padding: 16px 32px; font-size: 11px; color: #9ca3af; border-top: 1px solid #e5e7eb; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>RVOE·Track</h1>
    <span>Sistema de Gestión de Expedientes</span>
  </div>
  <div class="body">
    <div class="alerta-box">
      <div class="dias">${params.diasRestantes} día${params.diasRestantes !== 1 ? 's' : ''} hábil${params.diasRestantes !== 1 ? 'es' : ''}</div>
      <div class="label">para el vencimiento del plazo</div>
    </div>
    <div class="info-row"><div class="info-label">Etapa</div><div class="info-value"><strong>${params.etapaNombre}</strong></div></div>
    <div class="info-row"><div class="info-label">Expediente</div><div class="info-value">${params.folio}</div></div>
    <div class="info-row"><div class="info-label">Programa</div><div class="info-value">${params.programa}</div></div>
    <div class="info-row"><div class="info-label">Universidad</div><div class="info-value">${params.universidad}</div></div>
    <div class="info-row"><div class="info-label">Fecha límite</div><div class="info-value"><strong>${params.fechaLimite}</strong></div></div>
    <a href="${APP_URL}/expedientes/${params.expedienteId}" class="cta">Ver expediente →</a>
    <div class="fundamento">
      Base legal: ${params.fundamento} · Las fechas calculadas son una herramienta de apoyo. El criterio jurídico del área prevalece en todo momento.
    </div>
  </div>
  <div class="footer">
    Este mensaje fue generado automáticamente por RVOE·Track. No responder a este correo.
  </div>
</div>
</body>
</html>`

  return { subject, html }
}

// ============================================================
// Procesar alertas pendientes (llamar desde cron / API Route)
// ============================================================

export async function procesarAlertas(): Promise<{
  enviadas: number
  errores: number
}> {
  const sb = createClient()
  const hoy = toISODate(new Date())
  let enviadas = 0
  let errores = 0

  // Obtener configuración activa
  const { data: configs } = await sb
    .from('alertas_config')
    .select('*')
    .eq('activa', true)
  if (!configs?.length) return { enviadas, errores }
  const config = configs[0] as AlertasConfig

  // Obtener días inhábiles
  const { data: inhabiles } = await sb.from('dias_inhabiles').select('*')

  // Obtener etapas no completadas con expediente y responsable
  const { data: etapas } = await sb
    .from('etapas_expediente')
    .select(`
      *,
      expediente:expedientes(
        id, folio, programa_academico,
        universidad:universidades(nombre),
        responsable:usuarios(nombre, email)
      ),
      regla:reglas_plazo(fundamento_legal)
    `)
    .eq('completada', false)
    .not('fecha_calculada', 'is', null)
  if (!etapas) return { enviadas, errores }

  for (const etapa of etapas as unknown as (EtapaExpediente & {
    expediente: Expediente & {
      universidad: { nombre: string }
      responsable: Usuario
    }
    regla: { fundamento_legal: string }
  })[]) {
    if (!etapa.fecha_calculada) continue

    const diasRestantes = diasHabilesRestantes(
      etapa.fecha_calculada,
      (inhabiles ?? []) as any,
      hoy
    )

    // ¿Toca alertar hoy?
    const fechasAlerta = calcularFechasAlerta(
      etapa.fecha_calculada,
      config.dias_antes_habiles,
      (inhabiles ?? []) as any
    )
    const alertaHoy = fechasAlerta.find((f) => f.fecha === hoy)
    if (!alertaHoy) continue

    // Verificar si ya se envió esta alerta hoy
    const { data: yaEnviada } = await sb
      .from('alertas_log')
      .select('id')
      .eq('etapa_id', etapa.id)
      .eq('canal', 'email')
      .gte('enviada_en', `${hoy}T00:00:00Z`)
      .limit(1)
    if (yaEnviada?.length) continue

    // Destinatarios
    const destinatarios: string[] = []
    if (etapa.expediente?.responsable?.email) {
      destinatarios.push(etapa.expediente.responsable.email)
    }
    destinatarios.push(...config.destinatarios_adicionales)

    if (!destinatarios.length) continue

    const { subject, html } = plantillaAlerta({
      expedienteId: etapa.expediente_id,
      folio: etapa.expediente?.folio ?? '',
      programa: etapa.expediente?.programa_academico ?? '',
      universidad: etapa.expediente?.universidad?.nombre ?? '',
      etapaNombre: etapa.nombre_etapa,
      fechaLimite: fmtFecha(etapa.fecha_calculada),
      diasRestantes,
      fundamento: etapa.regla?.fundamento_legal ?? '',
    })

    for (const dest of destinatarios) {
      try {
        await resend.emails.send({
          from: FROM,
          to: dest,
          subject,
          html,
        })

        await sb.from('alertas_log').insert({
          etapa_id: etapa.id,
          expediente_id: etapa.expediente_id,
          canal: 'email',
          destinatario: dest,
          asunto: subject,
          enviada_en: new Date().toISOString(),
          exitosa: true,
        })
        enviadas++
      } catch (err: unknown) {
        await sb.from('alertas_log').insert({
          etapa_id: etapa.id,
          expediente_id: etapa.expediente_id,
          canal: 'email',
          destinatario: dest,
          asunto: subject,
          enviada_en: new Date().toISOString(),
          exitosa: false,
          error_detalle: String(err),
        })
        errores++
      }
    }
  }

  return { enviadas, errores }
}
