// ============================================================
// RVOE·Track — Capa de acceso a datos (DAL)
// lib/data.ts
// ============================================================
import { createClient } from './supabase'
import {
  Expediente, Universidad, Usuario, ReglasPlazo,
  DiaInhabil, EtapaExpediente, AlertasConfig, AlertaLog,
  Documento, HistorialCambio, ExpedienteConSemaforo,
} from '@/types'
import { calcularEtapasExpediente, semaforoExpediente, toISODate } from './fechas'

// ============================================================
// UNIVERSIDADES
// ============================================================

export async function getUniversidades(): Promise<Universidad[]> {
  const sb = createClient()
  const { data, error } = await sb
    .from('universidades')
    .select('*')
    .order('nombre')
  if (error) throw error
  return data as Universidad[]
}

export async function upsertUniversidad(
  univ: Partial<Universidad>
): Promise<Universidad> {
  const sb = createClient()
  const { data, error } = await sb
    .from('universidades')
    .upsert(univ)
    .select()
    .single()
  if (error) throw error
  return data as Universidad
}

// ============================================================
// USUARIOS
// ============================================================

export async function getUsuarios(): Promise<Usuario[]> {
  const sb = createClient()
  const { data, error } = await sb
    .from('usuarios')
    .select('*')
    .order('nombre')
  if (error) throw error
  return data as Usuario[]
}

export async function getUsuarioActual(): Promise<Usuario | null> {
  const sb = createClient()
  const { data: { user } } = await sb.auth.getUser()
  if (!user) return null
  const { data, error } = await sb
    .from('usuarios')
    .select('*')
    .eq('id', user.id)
    .single()
  if (error) return null
  return data as Usuario
}

// ============================================================
// EXPEDIENTES
// ============================================================

export async function getExpedientes(
  universidadId?: string
): Promise<ExpedienteConSemaforo[]> {
  const sb = createClient()
  let q = sb
    .from('v_expedientes_semaforo')
    .select('*')
    .eq('activo', true)
    .order('updated_at', { ascending: false })
  if (universidadId) q = q.eq('universidad_id', universidadId)
  const { data, error } = await q
  if (error) throw error
  return data as ExpedienteConSemaforo[]
}

export async function getExpedienteById(id: string): Promise<Expediente | null> {
  const sb = createClient()
  const { data, error } = await sb
    .from('expedientes')
    .select(`
      *,
      universidad:universidades(*),
      responsable:usuarios(*),
      etapas:etapas_expediente(*, regla:reglas_plazo(*))
    `)
    .eq('id', id)
    .single()
  if (error) return null
  return data as unknown as Expediente
}

export async function crearExpediente(
  payload: Omit<Expediente, 'id' | 'created_at' | 'updated_at' | 'etapas' | 'universidad' | 'responsable'>
): Promise<Expediente> {
  const sb = createClient()

  // Insertar expediente
  const { data, error } = await sb
    .from('expedientes')
    .insert(payload)
    .select()
    .single()
  if (error) throw error
  const exp = data as Expediente

  // Calcular y guardar etapas
  await recalcularEtapas(exp.id)

  return exp
}

export async function actualizarExpediente(
  id: string,
  payload: Partial<Expediente>
): Promise<Expediente> {
  const sb = createClient()
  const { data, error } = await sb
    .from('expedientes')
    .update(payload)
    .eq('id', id)
    .select()
    .single()
  if (error) throw error

  // Recalcular etapas cuando cambian fechas o flags
  const camposClave = [
    'fecha_inicio','fecha_notificacion','fecha_prevencion',
    'fecha_subsanacion','fecha_obtencion_rvoe','inicio_siguiente_ciclo',
    'tipo_tramite','participa_acreditadora','es_programa_salud','fecha_presentacion',
  ]
  if (camposClave.some((c) => c in payload)) {
    await recalcularEtapas(id)
  }

  return data as Expediente
}

/**
 * Recalcula todas las etapas de un expediente.
 * Borra las existentes no completadas y vuelve a generarlas.
 */
export async function recalcularEtapas(expedienteId: string): Promise<void> {
  const sb = createClient()

  // Obtener expediente completo
  const { data: exp } = await sb
    .from('expedientes')
    .select('*')
    .eq('id', expedienteId)
    .single()
  if (!exp) return

  // Obtener reglas activas y días inhábiles
  const [{ data: reglas }, { data: inhabiles }] = await Promise.all([
    sb.from('reglas_plazo').select('*').eq('activa', true).order('orden'),
    sb.from('dias_inhabiles').select('*').order('fecha'),
  ])

  const hoy = toISODate(new Date())
  const etapas = calcularEtapasExpediente(
    exp as Expediente,
    (reglas ?? []) as ReglasPlazo[],
    (inhabiles ?? []) as DiaInhabil[],
    hoy
  )

  // Borrar etapas no completadas
  await sb
    .from('etapas_expediente')
    .delete()
    .eq('expediente_id', expedienteId)
    .eq('completada', false)

  // Insertar nuevas etapas
  if (etapas.length > 0) {
    await sb.from('etapas_expediente').insert(
      etapas.map((e) => ({
        expediente_id: expedienteId,
        regla_id: e.regla_id,
        nombre_etapa: e.nombre_etapa,
        fecha_base: e.fecha_base,
        fecha_calculada: e.fecha_calculada,
        estado_semaforo: e.estado_semaforo,
        completada: false,
      }))
    )
  }
}

// ============================================================
// REGLAS DE PLAZO
// ============================================================

export async function getReglas(): Promise<ReglasPlazo[]> {
  const sb = createClient()
  const { data, error } = await sb
    .from('reglas_plazo')
    .select('*')
    .order('orden')
  if (error) throw error
  return data as ReglasPlazo[]
}

export async function toggleRegla(id: string, activa: boolean): Promise<void> {
  const sb = createClient()
  const { error } = await sb
    .from('reglas_plazo')
    .update({ activa })
    .eq('id', id)
  if (error) throw error
}

export async function upsertRegla(
  regla: Partial<ReglasPlazo>
): Promise<ReglasPlazo> {
  const sb = createClient()
  const { data, error } = await sb
    .from('reglas_plazo')
    .upsert(regla)
    .select()
    .single()
  if (error) throw error
  return data as ReglasPlazo
}

// ============================================================
// DÍAS INHÁBILES
// ============================================================

export async function getDiasInhabiles(): Promise<DiaInhabil[]> {
  const sb = createClient()
  const { data, error } = await sb
    .from('dias_inhabiles')
    .select('*')
    .order('fecha')
  if (error) throw error
  return data as DiaInhabil[]
}

export async function insertDiaInhabil(
  dia: Omit<DiaInhabil, 'id' | 'created_at'>
): Promise<DiaInhabil> {
  const sb = createClient()
  const { data, error } = await sb
    .from('dias_inhabiles')
    .insert(dia)
    .select()
    .single()
  if (error) throw error
  return data as DiaInhabil
}

export async function deleteDiaInhabil(id: string): Promise<void> {
  const sb = createClient()
  const { error } = await sb.from('dias_inhabiles').delete().eq('id', id)
  if (error) throw error
}

// ============================================================
// ALERTAS
// ============================================================

export async function getAlertasConfig(): Promise<AlertasConfig[]> {
  const sb = createClient()
  const { data, error } = await sb.from('alertas_config').select('*')
  if (error) throw error
  return data as AlertasConfig[]
}

export async function getAlertasLog(
  expedienteId?: string,
  limit = 50
): Promise<AlertaLog[]> {
  const sb = createClient()
  let q = sb
    .from('alertas_log')
    .select('*')
    .order('enviada_en', { ascending: false })
    .limit(limit)
  if (expedienteId) q = q.eq('expediente_id', expedienteId)
  const { data, error } = await q
  if (error) throw error
  return data as AlertaLog[]
}

// ============================================================
// DOCUMENTOS
// ============================================================

export async function getDocumentos(expedienteId: string): Promise<Documento[]> {
  const sb = createClient()
  const { data, error } = await sb
    .from('documentos')
    .select('*')
    .eq('expediente_id', expedienteId)
    .order('created_at', { ascending: false })
  if (error) throw error
  return data as Documento[]
}

export async function insertDocumento(
  doc: Omit<Documento, 'id' | 'created_at'>
): Promise<Documento> {
  const sb = createClient()
  const { data, error } = await sb
    .from('documentos')
    .insert(doc)
    .select()
    .single()
  if (error) throw error
  return data as Documento
}

export async function deleteDocumento(id: string): Promise<void> {
  const sb = createClient()
  const { error } = await sb.from('documentos').delete().eq('id', id)
  if (error) throw error
}

// ============================================================
// HISTORIAL
// ============================================================

export async function getHistorial(
  registroId: string,
  tabla = 'expedientes'
): Promise<HistorialCambio[]> {
  const sb = createClient()
  const { data, error } = await sb
    .from('historial_cambios')
    .select('*, usuario:usuarios(nombre, email)')
    .eq('registro_id', registroId)
    .eq('tabla', tabla)
    .order('created_at', { ascending: false })
    .limit(100)
  if (error) throw error
  return data as unknown as HistorialCambio[]
}

// ============================================================
// DASHBOARD: stats por universidad
// ============================================================

export async function getDashboardStats(universidadId?: string) {
  const expedientes = await getExpedientes(universidadId)

  const total = expedientes.length
  const porSemaforo = {
    rojo: expedientes.filter((e) => e.semaforo === 'rojo').length,
    amarillo: expedientes.filter((e) => e.semaforo === 'amarillo').length,
    verde: expedientes.filter((e) => e.semaforo === 'verde').length,
    gris: expedientes.filter((e) => e.semaforo === 'gris').length,
  }

  // Próximas fechas: tomar la proxima_fecha de cada expediente
  const proximas = expedientes
    .filter((e) => e.proxima_fecha)
    .sort((a, b) => (a.proxima_fecha ?? '').localeCompare(b.proxima_fecha ?? ''))
    .slice(0, 10)

  return { total, porSemaforo, proximas, expedientes }
}
