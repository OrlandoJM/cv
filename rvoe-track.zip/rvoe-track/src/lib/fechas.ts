// ============================================================
// RVOE·Track — Motor de cálculo de fechas hábiles
// lib/fechas.ts
// ============================================================
import { DiaInhabil, Expediente, ReglasPlazo, EtapaExpediente, Semaforo } from '@/types'

/**
 * Determina si una fecha es día hábil:
 * - No es sábado (6) ni domingo (0)
 * - No está en el catálogo de días inhábiles
 */
export function esDiaHabil(fecha: Date, inhabiles: DiaInhabil[]): boolean {
  const dow = fecha.getDay()
  if (dow === 0 || dow === 6) return false
  const iso = toISODate(fecha)
  return !inhabiles.some((d) => d.fecha === iso)
}

/**
 * Convierte un Date local a string YYYY-MM-DD sin problemas de zona horaria
 */
export function toISODate(date: Date): string {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

/**
 * Parsea un string YYYY-MM-DD a Date local (medianoche)
 * Evita el off-by-one de new Date("YYYY-MM-DD") que interpreta UTC
 */
export function parseDate(iso: string): Date {
  const [y, m, d] = iso.split('-').map(Number)
  return new Date(y, m - 1, d)
}

/**
 * Suma N días hábiles a una fecha base.
 * El cómputo inicia el día hábil SIGUIENTE a la fecha base (no el mismo día).
 * Si N es negativo, resta días hábiles (útil para plazos "antes de" una fecha).
 */
export function sumarDiasHabiles(
  fechaBase: string,
  n: number,
  inhabiles: DiaInhabil[]
): string {
  const base = parseDate(fechaBase)

  if (n === 0) return fechaBase

  if (n > 0) {
    // Avanzar: empieza el día siguiente
    const cursor = new Date(base)
    cursor.setDate(cursor.getDate() + 1)
    let contador = 0
    while (contador < n) {
      if (esDiaHabil(cursor, inhabiles)) {
        contador++
        if (contador === n) break
      }
      cursor.setDate(cursor.getDate() + 1)
    }
    return toISODate(cursor)
  } else {
    // Retroceder: empieza el día anterior
    const cursor = new Date(base)
    cursor.setDate(cursor.getDate() - 1)
    let contador = 0
    const abs = Math.abs(n)
    while (contador < abs) {
      if (esDiaHabil(cursor, inhabiles)) {
        contador++
        if (contador === abs) break
      }
      cursor.setDate(cursor.getDate() - 1)
    }
    return toISODate(cursor)
  }
}

/**
 * Suma N días naturales a una fecha base
 */
export function sumarDiasNaturales(fechaBase: string, n: number): string {
  const d = parseDate(fechaBase)
  d.setDate(d.getDate() + n)
  return toISODate(d)
}

/**
 * Cuenta días hábiles entre dos fechas (exclusivo en fecha_a, inclusivo en fecha_b)
 */
export function diasHabilesEntre(
  fechaA: string,
  fechaB: string,
  inhabiles: DiaInhabil[]
): number {
  const a = parseDate(fechaA)
  const b = parseDate(fechaB)
  if (a >= b) return 0

  let contador = 0
  const cursor = new Date(a)
  cursor.setDate(cursor.getDate() + 1)

  while (cursor <= b) {
    if (esDiaHabil(cursor, inhabiles)) contador++
    cursor.setDate(cursor.getDate() + 1)
  }
  return contador
}

/**
 * Determina el semáforo de una etapa según la fecha calculada y los umbrales configurables
 */
export function calcularSemaforo(
  fechaCalculada: string | undefined,
  hoy: string,
  umbrales = { rojo: 3, amarillo: 15 },
  inhabiles: DiaInhabil[] = []
): Semaforo {
  if (!fechaCalculada) return 'gris'

  const fc = parseDate(fechaCalculada)
  const h = parseDate(hoy)

  if (fc < h) return 'rojo' // Vencida

  const diasRestantes = diasHabilesEntre(hoy, fechaCalculada, inhabiles)

  if (diasRestantes <= umbrales.rojo) return 'rojo'
  if (diasRestantes <= umbrales.amarillo) return 'amarillo'
  return 'verde'
}

/**
 * Evalúa si la condición JSONB de una regla se cumple para un expediente dado
 */
function evaluarCondicion(
  condicion: ReglasPlazo['condicion'],
  expediente: Partial<Expediente>
): boolean {
  if (!condicion) return true

  const valor = (expediente as Record<string, unknown>)[condicion.campo]

  if (condicion.op === 'no_nulo') return valor != null && valor !== ''
  if (condicion.op === 'es_nulo') return valor == null || valor === ''
  if (condicion.valor !== undefined) return valor === condicion.valor

  return true
}

/**
 * Calcula la fecha límite de una regla para un expediente concreto.
 * Retorna null si la regla no aplica (tipo_tramite distinto, condición no cumplida,
 * o fecha base ausente).
 */
export function calcularFechaRegla(
  expediente: Partial<Expediente>,
  regla: ReglasPlazo,
  inhabiles: DiaInhabil[]
): string | null {
  // Filtrar por tipo_tramite
  if (regla.tipo_tramite && regla.tipo_tramite !== expediente.tipo_tramite) {
    return null
  }

  // Evaluar condición
  if (!evaluarCondicion(regla.condicion, expediente)) return null

  // Obtener fecha base del expediente
  const fechaBase = (expediente as Record<string, unknown>)[
    regla.campo_fecha_base
  ] as string | undefined

  if (!fechaBase) return null

  // Calcular fecha según tipo
  if (regla.tipo_dias === 'habiles') {
    return sumarDiasHabiles(fechaBase, regla.dias, inhabiles)
  }
  return sumarDiasNaturales(fechaBase, regla.dias)
}

/**
 * Genera todas las etapas calculadas para un expediente
 * aplicando las reglas activas
 */
export function calcularEtapasExpediente(
  expediente: Partial<Expediente>,
  reglas: ReglasPlazo[],
  inhabiles: DiaInhabil[],
  hoy: string = toISODate(new Date()),
  umbrales = { rojo: 3, amarillo: 15 }
): Omit<EtapaExpediente, 'id' | 'created_at' | 'updated_at'>[] {
  const etapas: Omit<EtapaExpediente, 'id' | 'created_at' | 'updated_at'>[] = []

  for (const regla of reglas.filter((r) => r.activa)) {
    const fechaCalculada = calcularFechaRegla(expediente, regla, inhabiles)
    if (!fechaCalculada) continue

    const fechaBase = (expediente as Record<string, unknown>)[
      regla.campo_fecha_base
    ] as string | undefined

    etapas.push({
      expediente_id: expediente.id ?? '',
      regla_id: regla.id,
      nombre_etapa: regla.nombre,
      fecha_base: fechaBase,
      fecha_calculada: fechaCalculada,
      fecha_real: undefined,
      estado_semaforo: calcularSemaforo(fechaCalculada, hoy, umbrales, inhabiles),
      completada: false,
      notas: undefined,
      regla,
    })
  }

  // Ordenar por fecha calculada ascendente
  return etapas.sort((a, b) =>
    (a.fecha_calculada ?? '').localeCompare(b.fecha_calculada ?? '')
  )
}

/**
 * Semáforo consolidado de un expediente (el más crítico entre sus etapas activas)
 */
export function semaforoExpediente(etapas: Pick<EtapaExpediente, 'estado_semaforo' | 'completada'>[]): Semaforo {
  const activas = etapas.filter((e) => !e.completada)
  if (activas.some((e) => e.estado_semaforo === 'rojo')) return 'rojo'
  if (activas.some((e) => e.estado_semaforo === 'amarillo')) return 'amarillo'
  if (activas.some((e) => e.estado_semaforo === 'verde')) return 'verde'
  return 'gris'
}

/**
 * Calcula las fechas en que se deben enviar alertas para una etapa
 * según la configuración de días_antes_habiles
 */
export function calcularFechasAlerta(
  fechaCalculada: string,
  diasAntesHabiles: number[],
  inhabiles: DiaInhabil[]
): { dias: number; fecha: string }[] {
  return diasAntesHabiles.map((d) => ({
    dias: d,
    fecha: sumarDiasHabiles(fechaCalculada, -d, inhabiles),
  }))
}

/**
 * Formatea una fecha ISO a dd/mm/yyyy para mostrar en UI
 */
export function fmtFecha(iso: string | undefined | null): string {
  if (!iso) return '—'
  const [y, m, d] = iso.split('-')
  return `${d}/${m}/${y}`
}

/**
 * Días hábiles restantes desde hoy hasta una fecha (positivo = faltan, negativo = vencida)
 */
export function diasHabilesRestantes(
  fechaLimite: string,
  inhabiles: DiaInhabil[],
  hoy: string = toISODate(new Date())
): number {
  const h = parseDate(hoy)
  const l = parseDate(fechaLimite)
  if (l < h) return -diasHabilesEntre(fechaLimite, hoy, inhabiles)
  return diasHabilesEntre(hoy, fechaLimite, inhabiles)
}
