import { Semaforo, SEMAFORO_LABELS } from '@/types'

interface Props {
  value: Semaforo
  showLabel?: boolean
  size?: 'sm' | 'md'
}

export default function SemaforoChip({ value, showLabel = true, size = 'md' }: Props) {
  const cls: Record<Semaforo, string> = {
    verde:    'sem-verde',
    amarillo: 'sem-amarillo',
    rojo:     'sem-rojo',
    gris:     'sem-gris',
  }

  const dotColor: Record<Semaforo, string> = {
    verde:    'var(--c-green)',
    amarillo: 'var(--c-yellow)',
    rojo:     'var(--c-red)',
    gris:     'var(--c-muted)',
  }

  const px = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-[11px]'

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full font-mono font-medium ${px} ${cls[value]}`}
    >
      <span
        className="rounded-full flex-shrink-0"
        style={{
          width: size === 'sm' ? 5 : 6,
          height: size === 'sm' ? 5 : 6,
          background: dotColor[value],
        }}
      />
      {showLabel && (SEMAFORO_LABELS[value] ?? value)}
    </span>
  )
}
