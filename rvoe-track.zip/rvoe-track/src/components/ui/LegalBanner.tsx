import { Info } from 'lucide-react'

export default function LegalBanner() {
  return (
    <div
      className="flex items-center gap-2 px-6 py-2 text-[11px] text-muted"
      style={{
        background: 'rgba(79,142,247,.05)',
        borderBottom: '1px solid rgba(79,142,247,.12)',
      }}
    >
      <Info size={12} className="flex-shrink-0" style={{ color: 'var(--c-accent)' }} />
      <span>
        Las fechas calculadas son una herramienta de apoyo.{' '}
        <strong className="text-text font-medium">
          El criterio jurídico del área prevalece en todo momento.
        </strong>{' '}
        Toda modificación queda registrada en auditoría.
      </span>
    </div>
  )
}
