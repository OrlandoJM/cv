'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import {
  LayoutDashboard, FolderOpen, Scale, Calendar,
  Users, Bell, LogOut, Settings,
} from 'lucide-react'

const NAV_MAIN = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/expedientes', label: 'Expedientes', icon: FolderOpen },
]

const NAV_ADMIN = [
  { href: '/admin/reglas', label: 'Reglas de plazo', icon: Scale },
  { href: '/admin/inhabiles', label: 'Días inhábiles', icon: Calendar },
  { href: '/admin/usuarios', label: 'Usuarios', icon: Users },
  { href: '/admin/alertas', label: 'Alertas', icon: Bell },
]

export default function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const sb = createClient()

  async function handleLogout() {
    await sb.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  function isActive(href: string) {
    if (href === '/expedientes') return pathname.startsWith('/expedientes')
    if (href === '/dashboard') return pathname === '/dashboard'
    return pathname.startsWith(href)
  }

  return (
    <nav
      className="w-[220px] min-w-[220px] flex flex-col overflow-y-auto"
      style={{ background: 'var(--c-surface)', borderRight: '1px solid var(--c-border)' }}
    >
      {/* Logo */}
      <div className="px-5 py-[22px] pb-4" style={{ borderBottom: '1px solid var(--c-border)' }}>
        <h1
          className="font-head text-[18px] font-semibold text-text"
          style={{ letterSpacing: '-0.3px' }}
        >
          RVOE<span style={{ color: 'var(--c-accent2)' }}>·</span>Track
        </h1>
        <span
          className="font-mono text-[10px] text-accent block mt-0.5"
          style={{ letterSpacing: '0.5px', textTransform: 'uppercase' }}
        >
          Sistema Jurídico
        </span>
      </div>

      {/* Nav principal */}
      <div className="px-3 pt-4 pb-2">
        <p
          className="font-mono text-[10px] text-muted px-3 mb-1"
          style={{ letterSpacing: '0.8px', textTransform: 'uppercase' }}
        >
          Principal
        </p>
        {NAV_MAIN.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className={`flex items-center gap-2.5 px-3 py-2 my-0.5 rounded text-[13px] transition-all
              ${isActive(href)
                ? 'bg-accent/15 text-accent font-medium'
                : 'text-muted hover:bg-card hover:text-text'
              }`}
          >
            <Icon size={15} className="opacity-80 flex-shrink-0" />
            {label}
          </Link>
        ))}
      </div>

      {/* Nav administración */}
      <div className="px-3 pt-2 pb-2">
        <p
          className="font-mono text-[10px] text-muted px-3 mb-1"
          style={{ letterSpacing: '0.8px', textTransform: 'uppercase' }}
        >
          Administración
        </p>
        {NAV_ADMIN.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className={`flex items-center gap-2.5 px-3 py-2 my-0.5 rounded text-[13px] transition-all
              ${isActive(href)
                ? 'bg-accent/15 text-accent font-medium'
                : 'text-muted hover:bg-card hover:text-text'
              }`}
          >
            <Icon size={15} className="opacity-80 flex-shrink-0" />
            {label}
          </Link>
        ))}
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Aviso legal + logout */}
      <div className="p-4" style={{ borderTop: '1px solid var(--c-border)' }}>
        <div
          className="flex items-start gap-2 p-2.5 rounded mb-3 text-[10px] text-muted leading-relaxed"
          style={{ background: 'rgba(79,142,247,.08)', border: '1px solid rgba(79,142,247,.2)' }}
        >
          <span className="mt-0.5 flex-shrink-0">⚖️</span>
          <span>Las fechas son orientativas. El criterio jurídico prevalece.</span>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 text-[12px] text-muted hover:text-text transition-colors w-full px-2 py-1.5 rounded hover:bg-card"
        >
          <LogOut size={13} />
          Cerrar sesión
        </button>
      </div>
    </nav>
  )
}
