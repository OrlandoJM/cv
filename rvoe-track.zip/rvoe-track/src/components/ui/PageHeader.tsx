interface Props {
  title: string
  subtitle?: string
  children?: React.ReactNode
}

export default function PageHeader({ title, subtitle, children }: Props) {
  return (
    <div className="flex items-center justify-between px-7 py-5">
      <div>
        <h1
          className="font-head text-[22px] font-light text-text"
          style={{ letterSpacing: '-0.2px' }}
        >
          {title}
          {subtitle && (
            <span className="italic ml-1.5" style={{ color: 'var(--c-accent)' }}>
              {subtitle}
            </span>
          )}
        </h1>
      </div>
      {children && <div className="flex items-center gap-3">{children}</div>}
    </div>
  )
}
